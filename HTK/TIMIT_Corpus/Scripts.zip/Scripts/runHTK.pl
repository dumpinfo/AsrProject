# -*-Perl-*-

use ConfigVar;
use File::Basename;
use HTK_funct;

$line        = join " ", @ARGV;

if ((@ARGV < 1) || ($line !~ /config/)) {
  print STDERR "Usage: $0 -config file.cfg\n";
  print "[$#ARGV] $line\n";
  exit;
}
# Default values
%Default     = {
		RootDir      => "~/Research/Corpora/TIMIT_Corpus/TIMIT",
		SampleRate   => "16",
		corpus       => "TIMIT_CORPUS",
                print        => "",
	       };

# CommandLine options
@CommandLine = qw (RootDir=s
		   SampleRate=s
		   corpus=s
		   print
		  );
#
# Excuting ParseConfig from ConfigVar.pm
#
print stderr "Executing ParseConfig\n";
ParseConfig (\@CommandLine, \%Default, CORPUS);

%CORPUS        = %ConfigVar::CORPUS;

#foreach $key (sort %CORPUS) {
#  print "Key: $key \t=> Value: $CORPUS{$key}";
#}

$debug         = $CORPUS{debug};
$corpus        = $CORPUS{CorpusName};
$root_dir      = $CORPUS{RootDir};
$out_dir       = $CORPUS{OutputDir};
$sample_rate   = $CORPUS{SampleRate};
@HTKmonoPhones = @{$CORPUS{HTKmonoPhones}};
%HTKLabMap     = %{$CORPUS{LabMap}};
#
# Changinf working dir to out_dir
#
chdir ${out_dir};

$MonoPhones    = "lists/${corpus}monoPhonesList";
$featureFiles  = "train_mfc.scp";
$MLF           = "${corpus}\.mlf";
$protoName     = "proto_s1_m1_dc_${corpus}\.pcf";
$tgtDir        = "hmms/hmm.0";
$srcDir        = "proto";

HInit($MLF, $protoName, $MonoPhones, $tgtDir, $srcDir, $featureFiles);

