		 ATK/HTK Speech Recognition Software
		 ===================================

			     RELEASE 1.4
				   
	     == Windows/Visual Studio and Linux Version ==


LICENSE TERMS  
"""""""""""""

This software is copyright Cambridge University.  It may not be copied
or distributed to 3rd parties without the permission of the copyright
owner.  It is distributed for research and non-commercial use only.

This software depends on the HTK software package downloadable from
htk.eng.cam.ac.uk.  Use of this ATK release is contingent on the user
first registering and obtaining a valid license from htk.eng.cam.ac.uk
to use the HTK software.  The use of all derivative HTK software in
this ATK release is contingent on full adherence to that license.

Although not a license condition, all users of this package are
requested to report all bugs by emailing sjy@eng.cam.ac.uk.  Please
include ATK in the subject line - messages without ATK in the subject
line are likely to be ignored (see Reporting Problems below).

Contents
""""""""

ATK is distributed as a tarball which when unpacked will contain
the following 5 directories:

a) ATKLib:   the ATK source libraries for real-time applications of 
             HTK-based recognisers

b) HTKLib:   an ATK compatible version of the HTK Libraries with various
             extensions

c) HTKTools: some of the standard HTK Tools modified to compile with the
             ATK compatible HTKLib.  Note that HVite is not included since
             it will not compile under ATK,  use AVite instead.

d) ATKApps:  a set of example ATK applications, currently limited but
             more examples are in the pipeline

e) Resource: HMM models, dictionaries and support files for use in
             ATK applications.  


Compile Instructions (windows)
""""""""""""""""""""""""""""""

This distribution of ATK requires Visual Studio.NET (ie VS 7 or later).

A. Building the basic libraries and test Programs

 1. Open the HTKLib solution (HTKLib/HTKLib.sln), select the configuration 
    Debug_ATK and from the Build menu, build HTKLib

 2. Open the ATKLib solution (ATKLib/ATKLib.sln) , select the configuration 
    Debug and from the Build menu, build ATKLib

 3. In the solution explorer select TBase, select the configuration 
    Debug and build and execute TBase.   You should see
    3 yellow windows with red balls in each.  Click on a window and
    check that the balls get transferred from window to window.  This
    tests the ATK base classes.

 4. Now build TSource, TCode and TRec in the same way.  TSource just
    tests the audio source, TCode tests the audio plus coder and 
    TRec tests the full recognition system.   TRec expects inputs of
    the form "Dial one three nine seven" etc.  All test programs 
    Txxx have a config file of the form Txxx.cfg in the Test 
    directory.

 5. If all appears satisfactory, repeat the above selecting release in
    place of debug to build the release versions

B. Building a the ATK Compliant HTK Tools

 1. Open the HTKTools solution (HTKTools/HTKTools.sln)

 2. From the Build menu select Batch build and build all tools.
    This will leave executables in the Release and Debug directories.

 3. The install_tools script provides a convenient way to move these to 
    your bin directory

C. The ATK Applications

  For each app, open the appropriate sln file and build the
  application as normal.  In the case of AVite, testing is best done
  by opening a shell in the Test directory and typing arun.  The
  resulting help message indicates the options that can then be
  tried.  The recognition accuracy for the case of

            arun -g tg wl

  should be 100%.


The ATK system has been built and tested using both Windows 2000 and
XP.  Console based commands have been tested under Cygwin running the
bash shell. 

If problems occur running any of the programs, the mostly likely
cause is that the executable is not being executed in the correct
directory.  All ATK programs should be executed in the local Test
directory and, apart from AVite, which has its own shell command
to invoke it, the command arguments should be "-C xxxx.cfg" where
xxxx is the name of the tool.


Compiling instructions (Linux)
""""""""""""""""""""""""""""""

The environment variables for the compiler, compiler flags and link flags
(HTKCC, HTKCF, HTKCF) can be set, otherwise the defaults will be used.

The linux build requires both X11 and the pthreads libraries.  If the
location of the X11 library is non-standard (ie, not in
/usr/X11R6/lib), edit the Makefiles to reflect this.

Compiling ATK tools requires that both the ATK and HTK libraries are
built.

To build the HTK libraries change directories into the HTKLib
directory and type "make".  To build the ATK libraries, change into
the ATKLib directory and type "make".

If you wish to build the HTKTools (HERest, HList, etc), you must
compile the HTKLib libraries without the D_cplusplus option (ie,
remove the define for cplusplus).

You can now test the build of ATK by building some of the test
programs, such as TASource, TBase, TRec and TACode ("make TBase",
"make TRec", etc).  These will be automatically moved into the "Test"
directory where sample config files exist for them.  To run TASource
for example, move into the Test directory and type the command
"./TASource -C TSource.cfg". 
 
There are two sample applications: a sample spoken dialog system
(SSDS) and AVite: an ATK-version of HVite for offline viterbi
recognition.   To build these, move into the "ATKApps/ssds" or
"ATKApps/avite" directories and type "make"

ATK currently uses OSS for the sound control.  There are known
compatability issues with artsd and other mixer-type controllers.  

Release Notes for 1.4
"""""""""""""""""""""

1) The main new features in this release are full support for trigram
language models and Linux support.

2) The use of Visual Studio V6 has been replaced by the .NET V7 version.

3) A variety of minor bugs have been fixed.

Release Notes for 1.3
"""""""""""""""""""""

1) Each directory has a Visual Studio .dsw.  To compile a library or
application, open this file and then build using the Build menu (eg
F7) as normal.

2) HTKLib has two sets of settings labeled _ATK and _HTK.  The _ATK
version defines the compilation flag ATK which changes the behaviour
of the standard HTK lib files.  These changes are mainly concerned
with multithreading (HThreads) and the way that real time audio coding
is handled (ie HAudio and HParm).

3) HTKLib has also been enhanced in various other minor ways compared
to the current public HTK release (currently at version 3.2).  These
changes include extensions to HRec/HLM to support trigram language 
models and confidence scoring, HModel to support triphone synthesis and
HGraf to support multiple windows.  HNet also has a trace option which allows
a visual plot of the phone level recognition network to be displayed.

4) Only VS6 settings for a "debug" build have been implemented.

5) Compiled HTK tools are left in the local Debug or Release
directories.  To copy them to a 'bin' directory (specified by setting
the shell variable HBIN to the required path) run the 'install_tools'
script.

6) The ATKLib contains a number of simple test programs (named
Tlibname).  These should be built and tested before attempting
to build any ATK based applications.

7) This release contains 1 set of 4-mix word internal MFCC
triphones (MFCC_0_D_A) and 1 set of 4-mix word internal MFCC triphones
with the cepstral mean removed (MFCC_0_D_A_Z).  This latter set
requires running average cepstral mean removal to be enabled when
using ATK.  Both these acoustic models were trained using WSJCAM0.
Both model sets include the decision tree used for state tying
embedded within them.  This allows HModel to synthesise arbitrary
triphones on demand.  The _Z set also have a background model
supplied with them.

Reporting Problems
""""""""""""""""""

All users of ATK are requested to report bugs by emailing
sjy@eng.cam.ac.uk.  ATK must be included in the subject line otherwise
the message will almost certainly be treated as spam and ignored.  All
bug reports should include version information.  To obtain this in a
command line application, simply set the -V option as in HTK.  For all
other applications, set PRINTVERSIONINFO=T in the configuration file.
In both cases, the release number and individual component versions
are printed on the console.  If the ATK monitor is being used for
console output, then the display area will need to made large enough
to view the version information.


Last Updated
May 2004


