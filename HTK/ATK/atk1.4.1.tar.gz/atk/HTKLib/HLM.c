/* ----------------------------------------------------------- */
/*           _ ___   	     ___                               */
/*          |_| | |_/	  |_| | |_/    SPEECH                  */
/*          | | | | \  +  | | | | \    RECOGNITION             */
/*          =========	  =========    SOFTWARE                */
/*                                                             */
/* ================> ATK COMPATIBLE VERSION <================= */
/*                                                             */
/* ----------------------------------------------------------- */
/* developed at:                                               */
/*                                                             */
/*      Machine Intelligence Laboratory (Speech Group)         */
/*      Cambridge University Engineering Department            */
/*      http://mi.eng.cam.ac.uk/                               */
/*                                                             */
/*      Entropic Cambridge Research Laboratory                 */
/*      (now part of Microsoft)                                */
/*                                                             */
/* ----------------------------------------------------------- */
/*         Copyright: Microsoft Corporation                    */
/*          1995-2000 Redmond, Washington USA                  */
/*                    http://www.microsoft.com                 */
/*                                                             */
/*          2001-2004 Cambridge University                     */
/*                    Engineering Department                   */
/*                                                             */
/*   Use of this software is governed by a License Agreement   */
/*    ** See the file License for the Conditions of Use  **    */
/*    **     This banner notice must not be removed      **    */
/*                                                             */
/* ----------------------------------------------------------- */
/*           File: HLM.c -   language model handling           */
/* ----------------------------------------------------------- */

char *hlm_version = "!HVER!HLM:   3.2.D0 [SJY 05/08/04]";

#include "HShell.h"
#include "HMem.h"
#include "HMath.h"
#include "HWave.h"
#include "HLabel.h"
#include "HDict.h"
#include "HLM.h"

/* --------------------------- Trace Flags ------------------------- */

#define T_TIO 1  /* Progress tracing whilst performing IO */

static int trace=0;

/* --------------------------- Initialisation ---------------------- */

#define LN10 2.30258509299404568 /* Defined to save recalculating it */

static Boolean rawMITFormat = FALSE;    /* Don't use HTK quoting and escapes */
static Boolean upperCaseLM = FALSE;     /* map all words to upper case */


static ConfParam *cParm[MAXGLOBS];      /* config parameters */
static int nParm = 0;

/* EXPORT->InitLM: initialise configuration parameters */
void InitLM(void)
{
   Boolean b;
   int i;

   Register(hlm_version);
   nParm = GetConfig("HLM", TRUE, cParm, MAXGLOBS);
   if (nParm>0){
      if (GetConfInt(cParm,nParm,"TRACE",&i)) trace = i;
      if (GetConfBool(cParm,nParm,"RAWMITFORMAT",&b)) rawMITFormat = b;
      if (GetConfBool(cParm,nParm,"UPPERCASELM",&b)) upperCaseLM = b;
   }
}

/*------------------------- Input Scanner ---------------------------*/

static Source source;           /* input file */

/* GetInLine: read a complete line from source */
static char *GetInLine(char *buf)
{
   int  i, c;

   c = GetCh(&source);
   if (c==EOF)
      return NULL;
   i = 0;
   while (c!='\n' && i<MAXSTRLEN) { 
      buf[i++] = c;
      c = GetCh(&source);
   } 
   buf[i] = '\0';
   return buf;
}

/* SyncStr: read input until str found */
static void SyncStr(char *buf,char *str)
{
   while (strcmp(buf, str)!=0) {
      if (GetInLine(buf)==NULL)
         HError(8150,"SyncStr: EOF searching for %s", str);
   }
}

/* GetInt: read int from input stream */
static int GetInt(void)
{
   int x;
   char buf[100];
   
   if (!ReadInt(&source,&x,1,FALSE))
      HError(8150,"GetInt: Int Expected at %s",SrcPosition(source,buf));
   return x;
}

/* GetFLoat: read float from input stream */
static float GetFloat(Boolean bin)
{
   float x;
   char buf[100];

   if (!ReadFloat(&source,&x,1,bin))
      HError(8150,"GetFloat: Float Expected at %s",SrcPosition(source,buf));
   return x;
}

/* ReadLMWord: read a string from input stream */
static char *ReadLMWord(char *buf)
{
   int i, c;
   char *s;
   
   if (rawMITFormat) {
      while (isspace(c=GetCh(&source)));
      i=0;
      while (!isspace(c) && c!=EOF && i<MAXSTRLEN){
         buf[i++] = c; c=GetCh(&source);
      }
      buf[i] = '\0';
      UnGetCh(c,&source);
      if (i>0) {
         if (upperCaseLM) {
            for (s=buf; *s!='\0'; s++) *s = toupper(*s);
         }
         return buf;
      } else
         return NULL;
   } else {
      if (ReadString(&source,buf)){
         if (upperCaseLM){
            for (s=buf; *s!='\0'; s++) *s = toupper(*s);
         }
         return buf;
      } else
         return NULL;
   }
}

/*------------------------- NEntry handling ---------------------------*/

static int hvs[]= { 165902236, 220889002, 32510287, 117809592,
                    165902236, 220889002, 32510287, 117809592 };

/* EXPORT->GetNEntry: Access specific NGram entry indexed by ndx */
NEntry *GetNEntry(NGramLM *nglm,lmId ndx[NSIZE],Boolean create)
{
   NEntry *ne;
   unsigned int hash;
   int i;
   /* #define LM_HASH_CHECK */
  
   hash=0;
   for (i=0;i<NSIZE-1;i++)
      hash=hash+(ndx[i]*hvs[i]);
   hash=(hash>>7)&(nglm->hashsize-1);
  
   for (ne=nglm->hashtab[hash]; ne!=NULL; ne=ne->link) {
      if (ne->word[0]==ndx[0] && ne->word[1]==ndx[1]) break;
   }

   if (ne==NULL && create) {
      ne=(NEntry *) New(nglm->heap,sizeof(NEntry));
      nglm->counts[0]++;
      
      for (i=0;i<NSIZE-1;i++)
         ne->word[i]=ndx[i];
      ne->user=0;
      ne->nse=0;
      ne->se=NULL;;
      ne->bowt=0.0;
      ne->link=nglm->hashtab[hash];
      nglm->hashtab[hash]=ne;
   }

   return(ne);
}

/*--------------------- ARPA-style NGrams ------------------------*/

static int se_cmp(const void *v1,const void *v2)
{
   SEntry *s1,*s2;

   s1=(SEntry*)v1;s2=(SEntry*)v2;
   return((int)(s1->word-s2->word));
}

static int nep_cmp(const void *v1,const void *v2)
{
   NEntry *n1,*n2;
   int res,i;

   res=0; n1=*((NEntry**)v1); n2=*((NEntry**)v2);
   for(i=NSIZE-2;i>=0;i--)
      if (n1->word[i]!=n2->word[i]) {
         res=(n1->word[i]-n2->word[i]);
         break;
      }
   return(res);
}

#define PROGRESS(g) \
   if (trace&T_TIO) { \
      if ((g%25000)==0) \
         printf(". "),fflush(stdout); \
      if ((g%800000)==0) \
         printf("\n   "),fflush(stdout); \
   }


#define NGHSIZE1 8192
#define NGHSIZE2 32768
#define NGHSIZE3 131072

/* CreateBoNGram: Allocate and create basic NGram structures 
   Create backoff NGram language models with size defined by counts.
    vocSize=number of words in vocabulary
    counts[1]=number of unigrams
    counts[2]=approximate number of bigrams
    counts[3]=approximate number of trigrams
               (approximate sizes are used to determine hash table size)
*/
static NGramLM *CreateBoNGram(LModel *lm,int vocSize, int counts[NSIZE])
{
   lmId ndx[NSIZE];
   int i,k;
   NGramLM *nglm;

   nglm = (NGramLM *) New(lm->heap, sizeof(NGramLM));
   lm->ngram = nglm;
   nglm->heap = lm->heap;

   for (i=0;i<=NSIZE;i++) nglm->counts[i]=0;
   for (i=1;i<=NSIZE;i++)
      if (counts[i]==0) break;
      else nglm->counts[i]=counts[i];
   nglm->nsize=i-1;

   /* Don't count final layer */
   for (k=0,i=1;i<nglm->nsize;i++) 
      k+=nglm->counts[i];
   /* Then use total to guess NEntry hash size */
   if (k<25000) 
      nglm->hashsize=NGHSIZE1;
   else if (k<250000) 
      nglm->hashsize=NGHSIZE2;
   else 
      nglm->hashsize=NGHSIZE3;

   nglm->hashtab=(NEntry **) New(lm->heap,sizeof(NEntry*)*nglm->hashsize);
   for (i=0; i<nglm->hashsize; i++) 
      nglm->hashtab[i]=NULL;

   nglm->vocSize = vocSize;
   nglm->unigrams = CreateVector(lm->heap,nglm->vocSize);
   nglm->wdlist = (LabId *) New(lm->heap,nglm->vocSize*sizeof(LabId)); nglm->wdlist--;
   for (i=1;i<=nglm->vocSize;i++) nglm->wdlist[i]=NULL;

   for (i=0;i<NSIZE;i++) ndx[i]=0;
   GetNEntry(nglm,ndx,TRUE);

   return(nglm);
}   

#define BIN_ARPA_HAS_BOWT 1
#define BIN_ARPA_INT_LMID 2

/* ReadNGrams: read n grams list from file */
static int ReadNGrams(NGramLM *nglm,int n,int count, Boolean bin)
{
   float prob;
   LabId wdid;
   SEntry *cse;
   char wd[255];
   lmId ndx[NSIZE+1];
   NEntry *ne,*le=NULL;
   int i, g, idx, total;
   unsigned char size, flags;

   cse = (SEntry *) New(nglm->heap,count*sizeof(SEntry));
   for (i=1;i<=NSIZE;i++) ndx[i]=0;

   if (trace&T_TIO)
      printf("\nn%1d ",n),fflush(stdout);

   total=0;
   for (g=1; g<=count; g++){
      PROGRESS(g);

      if (bin) {
         size = GetCh (&source);
         flags = GetCh (&source);
      }
      
      prob = GetFloat(bin)*LN10;

      if (n==1) { /* unigram treated as special */
         ReadLMWord(wd);
         wdid = GetLabId(wd, TRUE);
         if (wdid->lmid != 0)
            HError(8150,"ReadNGrams: Duplicate word (%s) in 1-gram list", wdid->name);
         wdid->lmid = g;
         nglm->wdlist[g] = wdid;
         nglm->unigrams[g] = prob;
         ndx[0]=g;
      } else {    /* bigram, trigram, etc. */
         for (i=0;i<n;i++) {
            if (bin) {
               if (flags & BIN_ARPA_INT_LMID) {
                  unsigned int ui;
                  if (!ReadInt (&source, &ui, 1, bin))
                     HError (9999, "ReadNGrams: failed reading int lm word id");
                  idx = ui;
               }
               else {
                  unsigned short us;
                  if (!ReadShort (&source, &us, 1, bin))
                     HError (9999, "ReadNGrams: failed reading short lm word id at");
                  idx = us;
               }
            }
            else {
               ReadLMWord(wd);
               wdid = GetLabId(wd, FALSE);
               idx = (wdid==NULL?0:wdid->lmid);
            }
            if (idx<1 || idx>nglm->vocSize)
               HError(8150,"ReadNGrams: Unseen word (%s) in %dGram",wd,n);
            ndx[n-1-i]=idx;
         }
      }

      total++;
      ne = GetNEntry(nglm,ndx+1,FALSE);
      if (ne == NULL)
         HError(8150,"ReadNGrams: Backoff weight not seen for %dth %dGram",g,n);
      if (ne!=le) {
         if (le != NULL && ne->se != NULL)
            HError(8150,"ReadNGrams: %dth %dGrams out of order",g,n);
         if (le != NULL) {
            if (le->nse==0) {
               le->se=NULL;
            } else {
               qsort(le->se,le->nse,sizeof(SEntry),se_cmp);
            }
         }
         ne->se = cse;
         ne->nse = 0;
         le = ne;
      }
      cse->prob = prob;
      cse->word = ndx[0];
      ne->nse++; cse++;

      /* read back-off weight */
      if (bin) {
         if (flags & BIN_ARPA_HAS_BOWT) {
            ne = GetNEntry(nglm,ndx,TRUE);
            ne->bowt = GetFloat (TRUE)*LN10;
         }
      }
      else {
         SkipWhiteSpace(&source);
         if (!source.wasNewline) {
            ne=GetNEntry(nglm,ndx,TRUE);
            ne->bowt = GetFloat(FALSE)*LN10;
         }
      }
   }

   /* deal with the last accumulated set */
   if (le != NULL) {
      if (le->nse==0) {
         le->se=NULL;
      } else {
         qsort(le->se,le->nse,sizeof(SEntry),se_cmp);
      }
   }

   if (trace&T_TIO)
      printf("\n"),fflush(stdout);

   return(total);
}

/* ReadBoNGram: read and store WSJ/DP format ngram */
static void ReadBoNGram(LModel *lm,char *fn)
{
   NGramLM *nglm;
   int i,j,k,counts[NSIZE+1];
   Boolean ngBin[NSIZE+1];
   char buf[MAXSTRLEN+1],syc[64];
   char ngFmtCh;

   if (trace&T_TIO)
      printf("\nBOffB "),fflush(stdout);

   if(InitSource(fn,&source,LangModFilter)<SUCCESS)
      HError(8110,"ReadBoNGram: Can't open file %s", fn);
   GetInLine(buf);
   SyncStr(buf,"\\data\\");
   for (i=1;i<=NSIZE;i++) counts[i]=0;
   for (i=1;i<=NSIZE;i++) {
      GetInLine(buf);
      if (sscanf(buf, "ngram %d%c%d", &j, &ngFmtCh, &k)!=3 && i>1)
         break;
      if (i!=j || k==0) 
         HError(8150,"ReadBoNGram: %dGram count missing (%s)",i,buf);

      switch (ngFmtCh) {
      case '=':
         ngBin[j] = FALSE;
         break;
      case '~':
         ngBin[j] = TRUE;
         break;
      default:
         HError (9999, "ReadARPALM: unknown ngram format type '%c'", ngFmtCh);
      }
      counts[j]=k;
   }

   if (ngBin[1])
      HError (8113, "ReadARPALM: unigram must be stored as text");

   nglm=CreateBoNGram(lm,counts[1],counts);
   for (i=1;i<=nglm->nsize;i++) {
      sprintf(syc,"\\%d-grams:",i);
      SyncStr(buf,syc);
      ReadNGrams(nglm,i,nglm->counts[i], ngBin[i]);
   }
   SyncStr(buf,"\\end\\");
   CloseSource(&source);

   if (trace&T_TIO) {
      printf("\n NEntry==%d ",nglm->counts[0]);
      for(i=1;i<=nglm->nsize;i++)
         printf(" %d-Grams==%d",i,nglm->counts[i]);
      printf("\n\n");
      fflush(stdout);
   }
}

/*------------------------- User Interface --------------------*/

/* EXPORT->GetLMProb: return probability of word wd_id following hist */
float GetLMProb(LModel *lm, LMHistory hist, LabId wdid)
{
   NEntry *ne;
   SEntry *se;
   lmId word;
   LogFloat bowt;
   int i,s,l,u;
   TGCache *t;
  
   word = wdid->lmid;

   /* if illegal just return LZERO */
   if (word==0 || word>lm->ngram->vocSize)
      HError(999,"word %s is not in NGram LM",wdid->name);
    
   /* if ngram hashed then return it */
   t = lm->htab + (hist.key*word) % TGHASHSIZE;
   if (t->word == word && t->hkey == hist.key) {
      return t->prob;
   }
   t->word = word; t->hkey = hist.key;
   
   /* not hashed so look it up */
   s = -1;
   if (hist.word[0] != 0) { 
      s=0;
      if (hist.word[1] != 0)  s=1;
   }
   
   /* If no history return unigram */
   if (s<0) {
      if (word!=0)
         t->prob = lm->ngram->unigrams[word];
      else
         t->prob = log(1.0/lm->ngram->vocSize);
      return t->prob;
   }
   
   ne = GetNEntry(lm->ngram,hist.word,FALSE);
   
   /* binary search for required ngram */
   if (ne != NULL) {  
      l = 0; u = ne->nse-1; se = NULL;
      while(l<=u) {
         i = (l+u)/2;
         if (ne->se[i].word==word) {
            se = ne->se+i; break;
         }
         if (ne->se[i].word>word) u = i-1; else l = i+1;
      }
      if (se != NULL) {
         t->prob = se->prob; return t->prob;
      }
      bowt=ne->bowt;
   } else {
      bowt=0.0;
   }
   
   /* ngram not found, so recurse */
   if (s==0)
      t->prob = lm->ngram->unigrams[word]+bowt; /* Backoff to unigram */
   else {
      hist.word[1] = 0;
      t->prob = bowt+GetLMProb(lm,hist,wdid);       /* else recurse */
   }
   return t->prob;
}

/* EXPORT->ReadLModel: Determine LM type and then read-in */
LModel *ReadLModel(MemHeap *heap,char *fn)
{
   LModel *lm;
   int i;

   lm=(LModel*)New(heap,sizeof(LModel));
   lm->heap=heap;
   lm->name=CopyString(heap,fn);

   ReadBoNGram(lm,fn);
   for (i=0; i<TGHASHSIZE; i++) {
      lm->htab[i].word = 0; 
   }
   return(lm);
}

/* EXPORT->DeleteLModel: Delete given language model */
void DeleteLModel(LModel *lm)
{
   DeleteHeap(lm->heap);
}  

/* EXPORT->SetLMHistory: return updated history w preceded by prev.word[0] */
LMHistory SetLMHistory(LabId w, LMHistory prev)
{
   LMHistory h;
   if (w==NULL) return prev;
   h.word[0] = w->lmid;
   h.word[1] = prev.word[0];
   return h;
}

/* EXPORT->Return labid corresponding to LM id w */
LabId GetLMName(LModel *lm, lmId w)
{
   if (w!=0) return lm->ngram->wdlist[w];
   return NULL;
}

/* ------------------------- End of HLM.c ------------------------- */
