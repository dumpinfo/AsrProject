/* ----------------------------------------------------------- */
/*   Example of Setting up HPARM as a Coder with an external   */
/*   source consisting of a simple sinewave generator          */
/* ----------------------------------------------------------- */

/* Steve Young, Jan 01 */

#include "HShell.h"
#include "HMem.h"
#include "HMath.h"
#include "HSigP.h"
#include "HAudio.h"
#include "HWave.h"
#include "HVQ.h"
#include "HParmATK.h"

/* Invoke with the name of the configuration file and the desired
   frequency of the external source.

      HCoder -C configfile sinefreq
*/

/* Define the external source 
   For this example, the "external source" will be a sine wave generator
   of unit amplitude and frequency set by the supplied "filename".

   Note that here we set 'xInfo' to NULL.  However, in a more general case, 
   it is useful to have somewhere to store generic application level 
   information.   For example, xInfo might contain generic information
   about some multichannel device, and bInfo might then contain the information
   specific to that particular channel.   
*/

static int nSpSamps;   /* number of samples in signal */
static int nSilSamps;  /* number of samples in silence */
static int nReps;      /* number of repetitions of signal */
static int sineFreq;   /* sine wave frequency */

typedef struct{      /* information needed to implement the source */
  float omega;
  float T;
  int nSp,nSil,nTotal;
  int nReps;
  int t;
} SineWave;

typedef SineWave *SWP;

/* open the source and return a reference to it */
Ptr sineOpen(Ptr xInfo, char *fn, BufferInfo *info)
{
  SWP srcInfo;   /* external source's private data */
  float f;

  srcInfo = (SWP)malloc(sizeof(SineWave));
  f = atof(fn);  srcInfo->omega = f * TPI;
  srcInfo->T = info->srcSampRate / 10000000;
  srcInfo->t = 0;
  srcInfo->nSp = nSpSamps;
  srcInfo->nSil = nSilSamps;
  srcInfo->nReps = nReps;
  srcInfo->nTotal = nSpSamps*nReps + nSilSamps*(nReps+1);
  printf("Sinewave %s source %d samples at frequency %.1f opened\n",fn,nSpSamps,f);
  printf(" %d reps: %d sil - %d speech\n",nReps,nSilSamps,nSpSamps);
  return (Ptr)srcInfo;
}

/* close the source and free up resources */
void sineClose(Ptr xInfo,Ptr bInfo)
{
  free(bInfo);
  printf("Sinewave source closed\n");
}

/* start the source - nothing to do in this case but in general this is the
   place to turn on the ADC or whatever
*/
void sineStart(Ptr xInfo,Ptr bInfo)
{
  printf("Sinewave starting\n");
}

/* stop the source - nothing to do in this case but in general this is the
   place to turn off the ADC or whatever
*/
void sineStop(Ptr xInfo,Ptr bInfo)
{
  printf("Sinewave stopping\n");
}

/* return number of samples available from the source without blocking.
   In general, this would be the number of samples waiting in the source
   input buffer (referenced via bInfo)
*/
int sineNumSamp(Ptr xInfo,Ptr bInfo)
{
  SWP p = (SWP)bInfo;
  int n;

  n = p->nTotal - p->t;
  return (n<=0)? 0 : n;
}

/* copy upto n samples from the source into data.  Return the number
   of samples actually copied.  This should never be less than the
   value returned by sineNumSamp.
*/
int sineGetData(Ptr xInfo,Ptr bInfo,int n,Ptr data)
{
  float silamp = 100;
  float spamp = 5000;
  SWP p = (SWP)bInfo;
  int i,m,rep;
  short *dp = (short *)data;
  short sx;
  float x,amp;

  for (i=0; i<n;i++){
    amp = spamp;
    rep = p->t/(p->nSil+p->nSp);
    if (rep>=p->nReps) amp=silamp; else {
      m = p->t - rep*(p->nSil+p->nSp);
      if (m<p->nSil) amp=silamp;
    }
    x = sin(p->omega *p->T * p->t)*amp;
    ++(p->t);
    if (p->t > p->nTotal) break;
    sx = x; *dp++ = sx;
  }
  return i;
}


/* ------------------- End of External Source Definition ---------------- */


ParmBuf pbuf;               /* parameter buffer used by coder */
HParmSrcDef ext;            /* external source for pbuf */
BufferInfo info;            /* user information extracted from pbuf */
Observation o;              /* output of coder */
int numS = 1;               /* number of streams: usually just 1 */

int main(int argc, char *argv[])
{
  int i;               /* output observation count */
  Boolean eSep;        /* used to set up observation */
  short swidth[SMAX];  /* copy of stream widths used to set up observation */
  char freq[20];          /* desired frequency encoded in external source file name */
  char tmp[100];

  /* *** STEP 1:  readin configuration file via HShell */

  if(InitShell(argc,argv,"","")<SUCCESS)
    HError(3200,"HCoder: InitShell failed");
  InitThreads(HT_MSGMON);
  /* 
     Config file is now in memory stored as a globally accessible
     linked list of ConfParam entries.  Each entry has
         modulename : parametername : parametervalue
  /*

  /**** STEP 2:  initialse the remaining HTK modules */
  InitMem();   InitLabel();
  InitMath();  InitSigP();
  InitWave();  InitAudio();
  InitVQ();
  if(InitParm()<SUCCESS)  
    HError(3200,"HCoder: InitParm failed");
  /* 
     InitParm creates a default ChannelInfo record and makes it
     the current channel.  The ChannelInfo record includes
     an IOConfigRec which is initialised from 'defConf' and then
     updated by scanning the ConfParm entries for modulename 'HPARM'
  */

  if (NumArgs() != 4){
    printf("Usage:  HCoder -C config freq nSpSamps nSilSamps nReps\n");
    exit(1);
  }
  sineFreq = GetIntArg();
  nSpSamps = GetIntArg();
  nSilSamps = GetIntArg();
  nReps = GetIntArg();

  /**** STEP 3:  create the external source definition */

  printf("3. Creating external source\n");
  ext = CreateSrcExt(NULL,          /* predefined static data needed by source */
		     WAVEFORM,      /* parameter kind of source */
		     2,             /* data size of source - short in this case */
		     0.0,           /* sample period (here we set it from config file) */
		     sineOpen, sineClose,   /* external source operations */
		     sineStart, sineStop,
		     sineNumSamp, 
		     sineGetData
		     );
  
  /**** STEP 4: Create the input buffer where HParm does its work */

  printf("4. Create the buffer\n");
  sprintf(freq,"%d",sineFreq);
  if((pbuf = OpenBuffer(&gstack,freq,ext))==NULL)
    HError(1150,"HCoder: Config parameters invalid");
  GetBufferInfo(pbuf,&info);
  /*
    info now contains a copy of the user accessible information stored
    in pbuf.  The details in info are sufficient to set up the
    observation record
  */


  /**** STEP 5: Create the Observation Record (the Coder output) */

  printf("5. Create the observation\n");
  ZeroStreamWidths(numS,swidth);
  SetStreamWidths(info.tgtPK,info.tgtVecSize,swidth,&eSep);
  o = MakeObservation(&gstack,swidth,info.tgtPK,FALSE,eSep);
  printf("Observation constructed [pk=%s, numStreams=%d, pvsize=%d\n",
	 ParmKind2Str(info.tgtPK,tmp),numS, info.tgtVecSize);
  ExplainObservation(&o, 10);
  /* 
     This step computes the stream widths 'swidth[1..numS]' and whether or 
     not the energies are in a separate stream 'eSep' using as input
     the target parameter kind 'tgtPK', the number of streams in 'numS' 
     and the total size of the target parameter vector in 'tgtVecSize'.  
     [  Note that the stream widths are also stored in HMM model sets and so 
     are often known already.  In this case, 'swidth[1..numS]' can be set in 
     advance leaving SetStreamWidths to only determine eSep. ]
  */

  /**** STEP 6: Run the coder */

  printf("6. Run the coder\n");
  StartBuffer(pbuf); i=0;
  while (BufferStatus(pbuf) != PB_CLEARED){
    if(ReadBuffer(pbuf,&o))
      PrintObservation(++i,&o,10);
  }
  CloseBuffer(pbuf);
}


