/* ----------------------------------------------------------- */
/*           _ ___   	     ___                               */
/*          |_| | |_/	  |_| | |_/    SPEECH                  */
/*          | | | | \  +  | | | | \    RECOGNITION             */
/*          =========	  =========    SOFTWARE                */
/*                                                             */
/* ================> ATK COMPATIBLE VERSION <================= */
/*                                                             */
/* ----------------------------------------------------------- */
/* developed at:                                               */
/*                                                             */
/*      Machine Intelligence Laboratory (Speech Group)         */
/*      Cambridge University Engineering Department            */
/*      http://mi.eng.cam.ac.uk/                               */
/*                                                             */
/*      Entropic Cambridge Research Laboratory                 */
/*      (now part of Microsoft)                                */
/*                                                             */
/* ----------------------------------------------------------- */
/*         Copyright: Microsoft Corporation                    */
/*          1995-2000 Redmond, Washington USA                  */
/*                    http://www.microsoft.com                 */
/*                                                             */
/*          2001-2004 Cambridge University                     */
/*                    Engineering Department                   */
/*                                                             */
/*   Use of this software is governed by a License Agreement   */
/*    ** See the file License for the Conditions of Use  **    */
/*    **     This banner notice must not be removed      **    */
/*                                                             */
/* ----------------------------------------------------------- */
/*           File: HSplit.c -  split a waveform file           */
/* ----------------------------------------------------------- */



char *hsplit_version = "!HVER!HSplit:   3.2.A2 [HY 06/11/02]";


#include "HShell.h"
#include "HMem.h"

/* -------------------------- Trace Flags ------------------------ */

static int trace = 0;
#define T_TOP  0001     /* Top Level tracing */
#define T_SRC  0002     /* Source file details */
#define T_LAB  0004     /* Segmentation process */
#define T_SEG  0010     /* Segmentation process */

/* ---------------------- Global Variables ----------------------- */

#define		MAX_PATH	1024
#define		PauseLen	0.5	/* Maximum pause in second*/

#define		_max(x,y)	(x<y)?y:x
#define		_min(x,y)	(x<y)?x:y


int    MaxSecs=15;
double silEnergy;        /* silence Energy threshold */
int    silCZero;         /* silence Zero Crossing threshold */
char   *srcFN;           /* name of source waveform */
FILE   *fp;              /* source waveform */
long flength;
long nSamps;             /* num samples in source waveform */
long sampRate;           /* sample rate (samps per second) */
long bpsample;           /* bytes per sample */
long bpsec;              /* bytes per second */
short fmt;         
short nChans;
short bpchan;
long frameSize;          /* samples per frame */
long srcNumFrames;       /* num frames in source */
long pauseframes;        /* num frames in a short pause */

char *splitBaseName="S";      /* base name of split files */
char splitDirName[MAX_PATH];  /* splitDirName to store split files */
int  fileidx=1;               /* index of next split file */
long maxSplitFrames;          /* max num frames in any split file */

char *framedata;         /* array of samples (bytes or shorts) */
Boolean *isSpeech;       /* array[frameindex] of Boolean */
char *splitData;         /* array of samples in output split file */

/* ---------------- Process Command Line ------------------------- */

static ConfParam *cParm[MAXGLOBS];
static int nParm = 0;            /* total num params */

/* SetConfParms: set conf parms relevant to this tool */
void SetConfParms(void)
{
   int i;
   double d;

   nParm = GetConfig("HSPLIT", TRUE, cParm, MAXGLOBS);
   if (nParm>0){
      if (GetConfInt(cParm,nParm,"TRACE",&i)) trace = i;
   }
}

void ReportUsage(void)
{
   printf("\nUSAGE: HSplit [options] src \n\n");
   printf(" Option                                       Default\n\n");
   printf(" -l dir   Output split waveform files to dir  current\n");
   printf(" -m t     Set maximum length to t secs (1~20) 15\n");
   printf(" -n N     Set index of first split file       1\n");
   printf(" -x s     Set split file base name            S\n");
   PrintStdOpts("");
   printf("\n\n");
}

/* ShowParams: print out characteristics of source waveform etc */
void ShowParams(){
    printf("  nSamps    = %d\n",nSamps);
    printf("  flength   = %d\n",flength);
	printf("  sampRate  = %d\n",sampRate);
    printf("  bpsample  = %d\n",bpsample);
	printf("  frameSize = %d\n",frameSize);
	printf("  srcNumFrms= %d\n",srcNumFrames);
	printf("  silEnergy = %f\n",silEnergy);
	printf("  silCZero  = %d\n",silCZero);
	printf("  maxSplitFr= %d\n",maxSplitFrames);
}

/* GetEngCZ:  Get the Energy and Cross Zero value of a speech frame */
void GetEngCZ(void *data, long length, short bpsample, double *Eng, int *CZ)
{
	int i, C=0;
	double E=0;
	if(bpsample==1)	/* 8 bits waveform file. */
	{
		char *Bdata=(char *)data;
		for (i=0;i<length-1;i++)
		{
			E=E+Bdata[i]*Bdata[i];
			C=C+(Bdata[i]*Bdata[i+1]<0);
		}
	}
	if(bpsample==2) /* 16 bits waveform file. */
	{
		short *Sdata=(short *)data;
		for (i=0;i<length-1;i++)
		{
			E=E+Sdata[i]*Sdata[i];
			C=C+(Sdata[i]*Sdata[i+1]<0);
		}
	}
	*Eng = E/(length-1);
	*CZ = C;
}

/* IsWave: check if the src file is a waveform */
Boolean IsWave(long *flength, long *nSamps, long *sampRate, long *bpsec, short *fmt, short *nChans, 
	short * bpsample, short *bpchan)
{
	char tmp[MAX_PATH];
	FILE *fp = fopen(srcFN,"rb");
	if (!fp)
		HError(1011,"IsWave: cannot open File %s",srcFN);
		
	fread(tmp,1,4,fp);
	tmp[4]=0;
	if (strcmp(tmp,"RIFF"))
	{
		fclose(fp);
		return FALSE;
	}
	fread(nSamps,4,1,fp);
	fread(tmp,1,8,fp);
	tmp[8]=0;
	if (strcmp(tmp,"WAVEfmt "))
	{
		fclose(fp);
		return FALSE;
	}
	fread(flength,4,1,fp);
	fread(fmt,2,1,fp);
	fread(nChans,2,1,fp);
	fread(sampRate,4,1,fp);
	fread(bpsec,4,1,fp);
	fread(bpsample,2,1,fp);
	fread(bpchan,2,1,fp);
	fread(tmp,1,4,fp);
	tmp[4]=0;
	if (strcmp(tmp,"data"))
	{
		fclose(fp);
		return FALSE;
	}
	fread(nSamps,4,1,fp);
	fclose(fp);
	return TRUE;
}

/* WriteWave:  Write a waveform file */
void WriteWave(void *data, long flength, long nSamps, long sampRate, long bpsec, short fmt, short nChans, 
	short bpsample, short bpchan, char *splitFileName)
{
	long tmp;
	FILE *fp = fopen(splitFileName,"wb");
	if (!fp)
		HError(1011,"WriteWave: cannot create file %s.",splitFileName);

	fwrite("RIFF",1,4,fp);
	tmp=nSamps+36;
	fwrite(&tmp,4,1,fp);
	fwrite("WAVEfmt ",1,8,fp);
	fwrite(&flength,4,1,fp);
	fwrite(&fmt,2,1,fp);
	fwrite(&nChans,2,1,fp);
	fwrite(&sampRate,4,1,fp);
	fwrite(&bpsec,4,1,fp);
	fwrite(&bpsample,2,1,fp);
	fwrite(&bpchan,2,1,fp);
	fwrite("data",1,4,fp);
	fwrite(&nSamps,4,1,fp);
	fwrite(data,1,nSamps,fp);
	fclose(fp);
}

/* Set Energy and Zero Crossing Thresholds from first 5 frames (ie 1 sec) */
void SetThresholds()
{
	int i,CZ;
	double Eng;

	silEnergy = 0.0;  silCZero = 0;	
	fseek(fp,44,SEEK_SET);	/* skip the waveform header. */
	for (i=0;i<5;i++)
	{
		fread(framedata,bpsample,frameSize,fp);
		GetEngCZ(framedata, frameSize, bpsample, &Eng, &CZ);
		silEnergy+=Eng;	 silCZero+=CZ;
	}
	silEnergy = (silEnergy/5)*2;
	silCZero = (silCZero/5)*2;
}

/* LabelSpeech:  label each frame of source file */
void LabelSpeech()
{
	int i,CZ,spFrames=0;
	double Eng;
	
	if (trace&T_TOP) printf("Labeling the source file...\n");
	fseek(fp,44,SEEK_SET);	/* skip the waveform header. */
	for (i=0; i<srcNumFrames; i++)
	{
		fread(framedata,bpsample,frameSize,fp);
		GetEngCZ(framedata, frameSize, bpsample, &Eng, &CZ);
		isSpeech[i] = FALSE;
		if (Eng>silEnergy || CZ > silCZero){
			isSpeech[i]=TRUE; ++spFrames;
		}
	}
	if (trace&T_LAB){
		printf("%d speech frames out of %d\n",spFrames,srcNumFrames);
		for (i=0; i<srcNumFrames; i++) { 
			if (i%50==0) printf("\n%5d: ",i);
			printf("%1d",isSpeech[i]);
		}
		printf("\n");
	}
	if (spFrames==0)
	   HError(1011,"HSplit: No speech frames found!");
}


/* Store the segment from fstart to fend in split file fileidx */

void StoreSplitFile(long fstart, long fend, int fileidx)
{
	long fsize = ((fend-fstart)+1)*frameSize;
    char splitFileName[MAX_PATH]; 

	fseek(fp,44+fstart*bpsample*frameSize,SEEK_SET);
	splitData = New(&gstack,fsize*bpsample);
	fread(splitData,bpsample, fsize, fp);
	sprintf(splitFileName,"%s%s%05d.wav",splitDirName,splitBaseName,fileidx);
	WriteWave(splitData, flength, fsize*bpsample, sampRate, bpsec, fmt, nChans, bpsample, 
			bpchan, splitFileName);
	Dispose(&gstack,splitData);
	if (trace&T_TOP)
		printf("Generated file %s [%d samples]\n", splitFileName, fsize);

}

/* ------------------ main program ---------------- */

int main(int argc, char *argv[])
{
	char *s;
	long i,length, fstart=0, fend=0, ftmp, maxuv, suv, euv;

	if(InitShell(argc,argv,hsplit_version)<SUCCESS)
      		HError(1000,"HSplit: InitShell failed");
	InitMem(); 
      	
	splitDirName[0]=0;	/* Initialize splitDirName */
    if (!InfoPrinted() && NumArgs() == 0)
      	      ReportUsage();
   	if (NumArgs() == 0) Exit(0);
   	
   	while (NextArg() == SWITCHARG) 
   	{
   		s = GetSwtArg();
   		if (strlen(s)!=1) 
   			HError(1019,"HSplit: Bad switch %s; must be single letter",s);
	      switch(s[0]){
	      case 'l':
	         if (NextArg() != STRINGARG)
	            HError(1019,"HSplit: split waveform file directory expected");
	         strcpy(splitDirName, GetStrArg());
	         if(splitDirName[strlen(splitDirName)-1]!='/')
	         	strcat(splitDirName,"/");
	         break;
	      case 'm':
	         MaxSecs = GetChkedFlt(1,20,s);
	         break;
		  case 'n':
             fileidx = GetChkedInt(1,1000000,s); 
			 break;
	      case 'x':
	         if (NextArg() != STRINGARG)
	            HError(1019,"HSplit: split file base name expected");
	         splitBaseName = GetStrArg();
	         break;
		  case 'T':
             trace = GetChkedInt(0,077,s); 
			 break;
	      default:
	         HError(1019,"HSplit: Unknown switch %s",s);
	      }
	}
	
	if (NumArgs() == 0)  
	      HError(1019,"HSplit: source waveform file expected");
	srcFN = GetStrArg();
		
	/* Check that source waveform is a WAV file */
	if(IsWave(&flength, &nSamps, &sampRate, &bpsec, &fmt, &nChans, &bpsample, &bpchan)==FALSE)
		HError(1011,"HSplit: %s is not a waveform file.", srcFN);
	nSamps /= bpsample;
	if(nChans!=1)
		HError(1011,"HSplit: cannot handle multi-channels waveform file.");
	if (bpsample>2)
		HError(1011,"HSplit: Bytes per sample larger than 2.");
	if (trace&T_TOP) printf("HSplit: %s -> %s%snnnn\n",srcFN,splitDirName,splitBaseName);

	/* Initialise parameters and data storage */
	frameSize=sampRate/50;      /* Set frame size to 20ms.  */
	if (nSamps < frameSize*5)   /* if the source file is too short then abort.  */
		HError(1011,"HSplit: source file too short (less than 1 second).");
	fp = fopen(srcFN,"rb");
	framedata=New(&gstack,frameSize*bpsample);
	maxSplitFrames = MaxSecs*sampRate/frameSize;	 /* the maximum number of frames in any split file. */
	srcNumFrames = nSamps/frameSize;	             /* the total number of frames. */
	pauseframes = PauseLen*sampRate/frameSize;       /* the number of frames for a short pause */
	isSpeech = New(&gstack,sizeof(Boolean)*srcNumFrames);
	SetThresholds();                                 /* Set Energy and CZ Thresholds */
	if (trace&T_SRC) ShowParams();

	/* Label each frame of the source file with speech/non-speech decision */
	LabelSpeech();
	
	/* Segment source file into split files */
	fseek(fp,44,SEEK_SET);
	while(!isSpeech[fend]) fend++;
	fstart = _max(0,fend-pauseframes);
	while(fend<srcNumFrames)
	{
		maxuv=0; suv=0; euv=0;
		fend=_min(fstart+maxSplitFrames, srcNumFrames);
		if (trace&T_SEG) printf("Segment %d: scanning %d->%d",fileidx,fstart,fend);

		while(fend>fstart+pauseframes)
		{
			while (isSpeech[fend] && fend>fstart+pauseframes) fend--;
			ftmp=fend;
			while (!isSpeech[ftmp] && ftmp>fstart+pauseframes) ftmp--;
			if(fend-ftmp>maxuv)
			{
				maxuv=fend-ftmp;
				suv=ftmp+1; euv=fend;
			}
			fend=ftmp;
		}
		if ((maxuv<5) && ((srcNumFrames-fstart) < maxSplitFrames) )
			fend = srcNumFrames;
		else if (maxuv>0)
			fend=_min(suv+pauseframes, (euv+suv)/2);
		else {
			HError(-1011,"HSplit: file %d has no trailing silence", fileidx);
			fend = fstart + maxSplitFrames;
		}
		if (trace&T_SEG) printf("  Final seg %d->%d  [gap=%d]\n",fstart,fend,maxuv);
		StoreSplitFile(fstart,fend,fileidx);		
		ftmp=fend; fileidx++;
		while(!isSpeech[fend] && fend<srcNumFrames) fend++;
		fstart=_max(ftmp,fend-pauseframes);
	}
	fclose(fp);
   	return 1;
}

/* ----------------------------------------------------------- */
/*                      END:  HSplit.c                         */
/* ----------------------------------------------------------- */
