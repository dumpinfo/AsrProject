/* ----------------------------------------------------------- */
/*           _ ___   	     ___                               */
/*          |_| | |_/	  |_| | |_/    SPEECH                  */
/*          | | | | \  +  | | | | \    RECOGNITION             */
/*          =========	  =========    SOFTWARE                */
/*                                                             */
/* ================> ATK COMPATIBLE VERSION <================= */
/*                                                             */
/* ----------------------------------------------------------- */
/* developed at:                                               */
/*                                                             */
/*      Machine Intelligence Laboratory (Speech Group)         */
/*      Cambridge University Engineering Department            */
/*      http://mi.eng.cam.ac.uk/                               */
/*                                                             */
/*      Entropic Cambridge Research Laboratory                 */
/*      (now part of Microsoft)                                */
/*                                                             */
/* ----------------------------------------------------------- */
/*         Copyright: Microsoft Corporation                    */
/*          1995-2000 Redmond, Washington USA                  */
/*                    http://www.microsoft.com                 */
/*                                                             */
/*          2001-2004 Cambridge University                     */
/*                    Engineering Department                   */
/*                                                             */
/*   Use of this software is governed by a License Agreement   */
/*    ** See the file License for the Conditions of Use  **    */
/*    **     This banner notice must not be removed      **    */
/*                                                             */
/* ----------------------------------------------------------- */
/*    File: HProfile.c - File: HProfile:  Profile a HMM Set    */
/* ----------------------------------------------------------- */


char *hprofile_version = "!HVER!HProfile:   3.0.A1 [SJY 09/05/01]";


/*
   This program is used to read in a set of HMM definitions
   and then print profile of the model set
*/

#include "HShell.h"
#include "HMem.h"
#include "HMath.h"
#include "HSigP.h"
#include "HAudio.h"
#include "HWave.h"
#include "HVQ.h"
#include "HParm.h"
#include "HLabel.h"
#include "HModel.h"
#include "HUtil.h"
#include "HDict.h"

static MemHeap hmmHeap;     /* Heap holds all hmm related info */

/* Global Settings */
static char * hmmListFN = NULL;  /* name of the list file */
static char * hmmDir = NULL;     /* directory to look for hmm def files */
static char * hmmExt = NULL;     /* hmm def file extension */
static char * dictfn = NULL;     /* name of a dictionary file if any */
static Boolean noAlias = FALSE;  /* set to zap all aliasses in hmmlist */
static Boolean chkDict = FALSE;  /* check hmm set dictionary coverage */

/* Global Data Structures */

static HMMSet hSet;        /* current HMM set */
static HMMSet *hset;       /* current HMM set */
static short fidx;         /* current macro file id */
static int maxStates;      /* max number of states in current HMM set */
static int maxMixes;       /* max number of mixes in current HMM set */

/* ---------------- Configuration Parameters --------------------- */

static ConfParam *cParm[MAXGLOBS];
static int nParm = 0;            /* total num params */

/* ------------------ Process Command Line -------------------------- */

void ReportUsage(void)
{
   printf("\nUSAGE: HProfile [options] hmmList\n\n");
   printf(" Option                                    Default\n\n");
   printf(" -p dict check phone coverage of dict       off\n");
   printf(" -d s    dir to find hmm definitions       current\n");
   printf(" -x s    extension for hmm files            none\n");
   printf(" -z      zap aliasses in hmmList\n");
   PrintStdOpts("HQ");
}

int main(int argc, char *argv[])
{
   char *s;
   void DoProfile(void);
   void CheckDict(char *dictfn);
   void ZapAliases(void);
   void Initialise(void);
   
   InitShell(argc,argv,hprofile_version);
   InitMem();   InitLabel();   InitMath();   InitSigP();
   InitWave();   InitAudio();   InitVQ();   InitParm();
   InitModel();   InitUtil(); InitDict();

   if (!InfoPrinted() && NumArgs() == 0)
      ReportUsage();
   if (NumArgs() == 0) Exit(0);
 
   CreateHeap(&hmmHeap,"Model Heap",MSTAK,1,1.0,40000,400000);
   CreateHMMSet(&hSet,&hmmHeap,TRUE);hset=&hSet;fidx=0;

   while (NextArg() == SWITCHARG) {
      s = GetSwtArg();
      if (strlen(s)!=1) 
         HError(2619,"HProfile: Bad switch %s; must be single letter",s);
      switch(s[0]) {
      case 'd':
         if (NextArg()!=STRINGARG)
            HError(2619,"HProfile: Input HMM directory expected");
         hmmDir = GetStrArg(); break;  
      case 'p':
	 if (NextArg()!=STRINGARG)
            HError(2619,"HProfile: name of a dictionary expected");
         dictfn = GetStrArg(); chkDict = TRUE; break;
      case 'x':
         if (NextArg()!=STRINGARG)
            HError(2619,"HProfile: Input HMM file extension expected");
         hmmExt = GetStrArg(); break;
      case 'z':
         noAlias = TRUE; break;
      case 'H':
         if (NextArg()!=STRINGARG)
            HError(2619,"HProfile: Input MMF file name expected");
         AddMMF(hset,GetStrArg());
         break;
      default:
         HError(2619,"HProfile: Unknown switch %s",s);
      }
   } 
   if (NextArg() != STRINGARG)
      HError(2619,"HProfile: HMM list file name expected");
   if (NumArgs()>1)
      HError(2619,"HProfile: Unexpected extra args on command line");
   hmmListFN = GetStrArg();
   Initialise();

   DoProfile();
   if (chkDict) CheckDict(dictfn);
   Exit(0);
}

/* --------------------- Initialisation --------------------- */

/* ZapAliases: reduce hList to just distinct physical HMM's */
void ZapAliases(void)
{
   int h;
   MLink q;
   HLink hmm;
   
   for (h=0; h<MACHASHSIZE; h++)
      for (q=hset->mtab[h]; q!=NULL; q=q->next)
         if (q->type=='l')
            DeleteMacro(hset,q);
   for (h=0; h<MACHASHSIZE; h++)
      for (q=hset->mtab[h]; q!=NULL; q=q->next)
         if (q->type=='h') {
            hmm=q->structure;
            NewMacro(hset,fidx,'l',q->id,hmm);
            hmm->nUse=1;
         }
}

/* Initialise: create and load the HMM set */ 
void Initialise()
{
   if (MakeHMMSet(&hSet,hmmListFN)<SUCCESS)
     HError(999,"Cannot make HMM Set");
   if (noAlias) ZapAliases(); 
   if (LoadHMMSet(&hSet,hmmDir,hmmExt)<SUCCESS)
     HError(999,"Cannot load HMM Set");
}

/* -------------------- Profile Routines -------------------- */
void PrintMacInfo()
{
   char *unk, *text[256];
   int  h,i,count[256];
   MLink p;

   unk = "unknown";
   for (i=0; i<256; i++) {
     count[i]=0;
     text[i] = unk;
   }
   text['h'] = "physical HMM";
   text['l'] = "logical HMM";
   text['s'] = "tied state";
   text['t'] = "tied transition matrix";
   for (h=0; h<MACHASHSIZE; h++)
     for (p=hset->mtab[h]; p!=NULL; p=p->next)
       ++count[p->type];
   printf("  Type  Count  Meaning\n");
   for (i=0; i<256; i++)
     if (count[i]>0)
       printf("    %c %7d  %s\n",i,count[i],text[i]);
}

typedef struct _PhonCell{
  char bname[10];
  int moncount;
  int lbicount;
  int rbicount;
  int tricount;
  struct _PhonCell *next;
} PhonCell;

void PrintPhoneSet()
{   
  MLink q; int h,i;
  PhonCell *p[256],*pp;   /* indexed on first phone letter */
  char c,fullname[100],basename[100];
  Boolean lc,rc;

   for (i=0; i<256; i++) p[i] = NULL;
   for (h=0; h<MACHASHSIZE; h++)
    for (q=hset->mtab[h]; q!=NULL; q=q->next)
      if (q->type == 'h'){
	q->id->aux = 0;
	strcpy(fullname,q->id->name);
	strcpy(basename,fullname);
	TriStrip(basename);
	c = basename[0];
	for (pp=p[c]; pp!=NULL && (strcmp(basename,pp->bname)!=0); pp=pp->next);
	if (pp==NULL) { /* add new entry */
	  pp = malloc(sizeof(PhonCell));
	  pp->moncount = 0;
	  pp->lbicount = 0;
	  pp->rbicount = 0;
	  pp->tricount = 0;
	  strcpy(pp->bname,basename);
	  pp->next = p[c]; p[c] = pp;
	}
	lc = strchr(fullname,'-') != NULL;
	rc = strchr(fullname,'+') != NULL;
	if (lc && rc) ++pp->tricount; else 
	if (lc && !rc) ++pp->lbicount;else
	if (!lc && rc) ++pp->rbicount;else
	  ++pp->moncount;
      }
   printf("BasePhone   #Mono   #LeftBi  #RightBi    #Triph\n");
   for (i=0; i<256; i++){
     for (pp=p[i]; pp!=NULL; pp=pp->next)
       printf("%6s %9d %9d %9d %9d\n",pp->bname,
	      pp->moncount,pp->lbicount,pp->rbicount,pp->tricount);
   }
}

LabId TestMono(LabId a)
{
  return NULL;
}

/* TestLBi: if "a-b" exists return NULL, otherwise insert "a-b" and return its id */
LabId TestLBi(LabId a, LabId b)
{
  char buf[50];
  LabId id;

  strcpy(buf,a->name); 
  strcat(buf,"-"); strcat(buf,b->name); 
  id = GetLabId(buf, FALSE);
  if (id==NULL) return GetLabId(buf, TRUE);
  return NULL;
}

/* TestRBi: if "b+c" exists return NULL, otherwise insert "b+c" and return its id */
LabId TestRBi(LabId b, LabId c)
{
  char buf[50];
  LabId id;

  strcpy(buf,b->name); 
  strcat(buf,"+"); strcat(buf,c->name); 
  id = GetLabId(buf, FALSE);
  if (id==NULL) return GetLabId(buf, TRUE);
  return NULL;
}

/* TestTri: if "a-b+c" exists return NULL, otherwise insert "a-b+c" and return its id */
LabId TestTri(LabId a, LabId b, LabId c)
{
  char buf[50];
  LabId id;

  strcpy(buf,a->name); 
  strcat(buf,"-"); strcat(buf,b->name); 
  strcat(buf,"+"); strcat(buf,c->name); 
  id = GetLabId(buf, FALSE);
  if (id==NULL) return GetLabId(buf, TRUE);
  return NULL;
}

void CheckDict(char *dictfn)
{
  Vocab voc;
  Word w;
  Pron p;
  int i,j,count = 0;
  LabId missing;

  printf("---------------------CHECK DICT: %s -------------------\n",dictfn);
  /* read in dictionary */
  InitVocab(&voc);
  ReadDict(dictfn,&voc);

  /* scan the dictionary */
  for (i=0; i<VHASHSIZE; i++) {
    for (w = voc.wtab[i]; w!=NULL; w=w->next) {
      for (p=w->pron; p!=NULL; p=p->next) if (p->nphones>0){
	missing = NULL;
	if (p->nphones==1){
	  missing = TestMono(p->phones[0]);
	} else {
	  missing = TestLBi(p->phones[0],p->phones[1]);
	  if (!missing) missing = TestRBi(p->phones[p->nphones-2],p->phones[p->nphones-1]);
	     for (j=1; !missing && j<p->nphones-1; j++)
	       missing = TestTri(p->phones[j-1],p->phones[j],p->phones[j+1]);
	}
	/* report missing phone if any */
	if (missing) {
	  ++count;
	  printf("%5s from %8s (",missing->name,p->word->wordName->name);
	  for (j=0; j<p->nphones; j++)
	    printf("%s ",p->phones[j]->name);
	  printf(")\n");
	}
      }
    }
  }
  if (count==0) 
    printf("Full coverage\n");
  else
    printf("%d models missing\n",count);
}

void DoProfile(void)
{
   char buf[20];
   MILink p;
   int i,S;
   
   printf("\n---------------------------- FILES -------------------------------\n");
   printf("HMM Set : ");
   if (hset->numFiles > 0) 
     for (p=hset->mmfNames; p!=NULL; p=p->next)
       fprintf(stdout," %s",p->fName);
   printf("\nHMM List:  %s\n",hmmListFN);
   printf(  "HMM Kind:  ");
   switch(hset->hsKind){
   case PLAINHS:  printf("PLAIN\n"); break;
   case SHAREDHS: printf("SHAREDHS\n"); break;
   case TIEDHS:   printf("TIEDHS\n"); break;
   case DISCRETEHS:   printf("DISCRETEHS\n"); break;
   }
   printf("\n");

   printf("------------------------- DIMENSIONS -----------------------------\n");
   printf("LogHMMs PhyHMMs States[Shared] Gaussians[Shared] TransP  Macros   Bytes\n");
   printf("%6d %7d %6d %7d %8d %7d %7d %7d %9d\n\n",
	  hset->numLogHMM,hset->numPhyHMM,
	  hset->numStates,hset->numSharedStates, hset->numMix, hset->numSharedMix,
	  hset->numTransP, hset->numMacros, hmmHeap.totUsed );
   
   printf("--------------------------- MACROS -------------------------------\n");
   if (HasMacros(hset,NULL)) {
     PrintMacInfo(); printf("\n");
   }else printf(" NONE\n\n");

   printf("-------------------------- FEATURES ------------------------------\n");
   printf("Parameter Kind = %s\n",ParmKind2Str(hset->pkind,buf)),
   S = hset->swidth[0];
   printf("VecSize = %d; Streams = %d [",hset->vecSize,S);
   for (i=1; i<=S; i++) 
      printf("%d%c",hset->swidth[i],i==S?']':'|'); 
   printf("\n\n");

   printf("-------------------------- PHONESET ------------------------------\n");
   PrintPhoneSet(); printf("\n");
}


/* ----------------------------------------------------------- */
/*                     END:  HProfile.c                        */
/* ----------------------------------------------------------- */
