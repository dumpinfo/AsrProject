/* ----------------------------------------------------------- */
/*           _ ___   	     ___                               */
/*          |_| | |_/	  |_| | |_/    SPEECH                  */
/*          | | | | \  +  | | | | \    RECOGNITION             */
/*          =========	  =========    SOFTWARE                */
/*                                                             */
/* ================> ATK COMPATIBLE VERSION <================= */
/*                                                             */
/* ----------------------------------------------------------- */
/* developed at:                                               */
/*                                                             */
/*      Machine Intelligence Laboratory (Speech Group)         */
/*      Cambridge University Engineering Department            */
/*      http://mi.eng.cam.ac.uk/                               */
/*                                                             */
/*      Entropic Cambridge Research Laboratory                 */
/*      (now part of Microsoft)                                */
/*                                                             */
/* ----------------------------------------------------------- */
/*         Copyright: Microsoft Corporation                    */
/*          1995-2000 Redmond, Washington USA                  */
/*                    http://www.microsoft.com                 */
/*                                                             */
/*          2001-2004 Cambridge University                     */
/*                    Engineering Department                   */
/*                                                             */
/*   Use of this software is governed by a License Agreement   */
/*    ** See the file License for the Conditions of Use  **    */
/*    **     This banner notice must not be removed      **    */
/*                                                             */
/* ----------------------------------------------------------- */
/*   File: HView.c - File: HView:  Interactive HMMSet Viewer   */
/* ----------------------------------------------------------- */



char *hview_version = "!HVER!HView:   3.2.A2 [SJY 09/05/01]";



/*
   This program is used to read in a set of HMM definitions
   and then interactively examine them.
*/

#include "HShell.h"
#include "HMem.h"
#include "HMath.h"
#include "HSigP.h"
#include "HAudio.h"
#include "HWave.h"
#include "HVQ.h"
#include "HParm.h"
#include "HLabel.h"
#include "HModel.h"
#include "HUtil.h"

static MemHeap hmmHeap;     /* Heap holds all hmm related info */

/* Global Settings */

static char * hmmDir = NULL;     /* directory to look for hmm def files */
static char * hmmExt = NULL;     /* hmm def file extension */
static Boolean noAlias = FALSE;  /* set to zap all aliasses in hmmlist */
static int  trace    = 0;        /* current trace level */

/* Global Data Structures */

static HMMSet hSet;        /* current HMM set */
static HMMSet *hset;       /* current HMM set */
static int fidx;           /* current macro file id */
static int maxStates;      /* max number of states in current HMM set */
static int maxMixes;       /* max number of mixes in current HMM set */

/* ---------------- Configuration Parameters --------------------- */

static ConfParam *cParm[MAXGLOBS];
static int nParm = 0;            /* total num params */

/* ------------------ Process Command Line -------------------------- */

void SetConfParms(void)
{
   int i;

   nParm = GetConfig("HHED", TRUE, cParm, MAXGLOBS);
   if (nParm>0) {
      if (GetConfInt(cParm,nParm,"TRACE",&i)) trace = i;
   }
}

void CmdSummary(void)
{
   printf("\nHView Command Summary\n\n");
   printf("LC                   - list commands ie this list\n");
   printf("LM pattern           - list macro names matching pattern\n");
   printf("PM pattern           - print macros matching pattern\n");
   printf("ST                   - show overall topology of model set\n");
}

void ReportUsage(void)
{
   printf("\nUSAGE: HView [options] hmmList\n\n");
   printf(" Option                                    Default\n\n");
   printf(" -d s    dir to find hmm definitions       current\n");
   printf(" -x s    extension for hmm files            none\n");
   printf(" -z      zap aliasses in hmmList\n");
   PrintStdOpts("HQ");
}

int main(int argc, char *argv[])
{
   char *s;
   void CommandLoop(void);
   void ZapAliases(void);
   void Initialise(char *hmmListFn);
   
   InitShell(argc,argv,hview_version);
   InitMem();
   InitLabel();
   InitMath();
   InitSigP();
   InitWave();
   InitAudio();
   InitVQ();
   InitParm();
   InitModel();
   InitUtil();

   if (!InfoPrinted() && NumArgs() == 0)
      ReportUsage();
   if (NumArgs() == 0) Exit(0);
   SetConfParms();
 
   CreateHeap(&hmmHeap,"Model Heap",MSTAK,1,1.0,40000,400000);
   CreateHMMSet(&hSet,&hmmHeap,TRUE);hset=&hSet;fidx=0;

   while (NextArg() == SWITCHARG) {
      s = GetSwtArg();
      if (strlen(s)!=1) 
         HError(2619,"HView: Bad switch %s; must be single letter",s);
      switch(s[0]) {
      case 'd':
         if (NextArg()!=STRINGARG)
            HError(2619,"HView: Input HMM definition directory expected");
         hmmDir = GetStrArg(); break;  
      case 'x':
         if (NextArg()!=STRINGARG)
            HError(2619,"HView: Input HMM file extension expected");
         hmmExt = GetStrArg(); break;
      case 'z':
         noAlias = TRUE; break;
      case 'H':
         if (NextArg()!=STRINGARG)
            HError(2619,"HView: Input MMF file name expected");
         AddMMF(hset,GetStrArg());
         break;
      case 'Q':
         CmdSummary(); exit(0);
      case 'T':
         trace = GetChkedInt(0,65535,s); break;
      default:
         HError(2619,"HView: Unknown switch %s",s);
      }
   } 
   if (NextArg() != STRINGARG)
      HError(2619,"HView: HMM list file name expected");
   if (NumArgs()>1)
      HError(2619,"HView: Unexpected extra args on command line");
   Initialise(GetStrArg());

   CommandLoop();
   Exit(0);
}

/* --------------------- Initialisation --------------------- */

/* ZapAliases: reduce hList to just distinct physical HMM's */
void ZapAliases(void)
{
   int h;
   MLink q;
   HLink hmm;
   
   for (h=0; h<MACHASHSIZE; h++)
      for (q=hset->mtab[h]; q!=NULL; q=q->next)
         if (q->type=='l')
            DeleteMacro(hset,q);
   for (h=0; h<MACHASHSIZE; h++)
      for (q=hset->mtab[h]; q!=NULL; q=q->next)
         if (q->type=='h') {
            hmm=q->structure;
            NewMacro(hset,fidx,'l',q->id,hmm);
            hmm->nUse=1;
         }
}

/* Initialise: create and load the HMM set */ 
void Initialise(char *hmmListFn)
{
   MakeHMMSet(&hSet,hmmListFn);
   if (noAlias) ZapAliases(); 
   LoadHMMSet(&hSet,hmmDir,hmmExt);
   maxStates = MaxStatesInSet(hset);
   maxMixes = MaxMixInSet(hset);
   if (trace != 0) {
      printf("HView\n");
      printf(" %d/%d Models Loaded [%d states max, %d mixes max]\n",
             hset->numLogHMM,hset->numPhyHMM,maxStates,maxMixes);
      fflush(stdout);
   }
}

/* -------------------- Utility Routines -------------------- */

/* GetCmdArg: extract first arg from args in arg and return rest */
char *GetCmdArg(char *arg, char *args){
   char *p,*q;
   
   p = args; q = arg;
   while (*p==' ') ++p;
   while (*p != 0) *q++ = *p++;
   *q = '\0';
   return p;
}

/* PausePrompt: press return to continue, returns char pressed */
char PausePrompt(char *prompt)
{
   char buf[10];
   printf("%s",prompt);
   gets(buf);
   return buf[0];
}

/* -------------------- Commands ---------------------------- */

/* ListCommands: list all HView commands */
void ListCommands(void)
{
   CmdSummary();
}

/* ShowTopology: show overall topology of hmm set */
void ShowTopology(void)
{
   PrintHSetProfile(stdout,hset);   
}

/* ListMacroNames: list macros whose name matches pattern in args */
void ListMacroNames(char *args)
{
   MLink m;
   int h,c=0;
   char pat[256];

   GetCmdArg(pat,args);
   printf("Listing Macro names matching %s\n",pat);
   for (h=0; h<MACHASHSIZE; h++)
      for (m=hset->mtab[h]; m!=NULL; m=m->next) {
	 if (DoMatch(m->id->name,pat)){
	    if (c++ == 10) {
	       c=0;
	       if (PausePrompt("Press return to continue, q to quit: ") == 'q') 
		  return;
	    }
	    printf("%s [%c]\n",m->id->name,m->type);
	 }
      }
}

/* CheckCKinds: list global ckinds and counts for all mixtures */
void CheckCKinds(void)
{
   int max=0,m,h,s;
   HLink hmm;
   MLink q;

   for (h=0; h<MACHASHSIZE; h++)
      for (q=hset->mtab[h]; q!=NULL; q=q->next)
	 if (q->type == 'h'){
	    hmm = (HLink)q->structure;
	    m = MaxMixtures(hmm);
	    if (m>max) max = m;
	 }
}

/* PrintMacros: print macros whose name matches pattern in args */
void PrintMacros(char *args)
{
   MLink m;
   int h;
   char pat[256],prompt[64];

   GetCmdArg(pat,args);
   printf("Printing Macros matching %s\n",pat);
   for (h=0; h<MACHASHSIZE; h++)
      for (m=hset->mtab[h]; m!=NULL; m=m->next) {
	 if (m->type != 'l' && DoMatch(m->id->name,pat)){
	    sprintf(prompt,"Macro %s: press return to continue, q to quit: ",
                    m->id->name);
            if (PausePrompt(prompt) == 'q') return;
	    PutMacro(hset,stdout,m,FALSE);
	 }
      }
}

/* -------------------- Top Level ---------------- */

static int  nCmds = 6;
static char *cmdmap[] = {"LM","PM","LC","ST","CC","QU"};
typedef enum { LM=1, PM, LC, ST, CC, QU} CmdNum;

/* CmdIndex: return index 1..N of given command */
CmdNum CmdIndex(char *s)
{
   int i;
   
   for (i=1; i<=nCmds; i++)
      if (strcmp(cmdmap[i-1],s) == 0) return i;
   return 0;
}

/* CommandLoop: main command loop */
void CommandLoop(void)
{
   char buf[256],*p;
   char cmd[3];

   for (;;) {
      printf("HView> "); p = gets(buf);
      while (*p == ' ') ++p;
      if (strlen(p) == 0) continue;
      cmd[0] = toupper(*p++); cmd[1] = toupper(*p++); cmd[2] = '\0';
      while (*p == ' ') ++p;
      switch (CmdIndex(cmd)){
	 case LM: ListMacroNames(p); break;
	 case PM: PrintMacros(p); break;
         case ST: ShowTopology(); break;
         case LC: ListCommands(); break; 
         case CC: CheckCKinds(); break;
	 case QU: exit(0);
	 default: 
	    printf("Error: command %s not recognised\n",cmd);
	    printf("       (Try LC to ListCommands)\n");
      }
   }
}


/* ----------------------------------------------------------- */
/*                        END:  HView.c                        */
/* ----------------------------------------------------------- */
