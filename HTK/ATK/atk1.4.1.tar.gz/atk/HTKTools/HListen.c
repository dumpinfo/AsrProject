/* ----------------------------------------------------------- */
/*           _ ___   	     ___                               */
/*          |_| | |_/	  |_| | |_/    SPEECH                  */
/*          | | | | \  +  | | | | \    RECOGNITION             */
/*          =========	  =========    SOFTWARE                */
/*                                                             */
/* ================> ATK COMPATIBLE VERSION <================= */
/*                                                             */
/* ----------------------------------------------------------- */
/* developed at:                                               */
/*                                                             */
/*      Machine Intelligence Laboratory (Speech Group)         */
/*      Cambridge University Engineering Department            */
/*      http://mi.eng.cam.ac.uk/                               */
/*                                                             */
/*      Entropic Cambridge Research Laboratory                 */
/*      (now part of Microsoft)                                */
/*                                                             */
/* ----------------------------------------------------------- */
/*         Copyright: Microsoft Corporation                    */
/*          1995-2000 Redmond, Washington USA                  */
/*                    http://www.microsoft.com                 */
/*                                                             */
/*          2001-2004 Cambridge University                     */
/*                    Engineering Department                   */
/*                                                             */
/*   Use of this software is governed by a License Agreement   */
/*    ** See the file License for the Conditions of Use  **    */
/*    **     This banner notice must not be removed      **    */
/*                                                             */
/* ----------------------------------------------------------- */
/*           File: HListen.c -  replay an audio file           */
/* ----------------------------------------------------------- */

char *hlisten_version = "!HVER!Hlisten:   3.0.A1 [CUED 05/09/00]";



#include "HShell.h"
#include "HMem.h"
#include "HMath.h"
#include "HSigP.h"
#include "HAudio.h"
#include "HWave.h"


/* -------------------------- Trace Flags ------------------------ */

static int trace = 0;
#define T_TOP  0001     /* Top Level tracing */

/* ---------------------- Global Variables ----------------------- */

static Boolean replay = FALSE;   /* replay audio */
static FileFormat ff = UNDEFF;   /* Source File format */


/* ---------------- Configuration Parameters --------------------- */

static ConfParam *cParm[MAXGLOBS];
static int nParm = 0;            /* total num params */
static HTime sampPeriod=0.0;         /* raw audio input only */
static int audSignal;

/* ---------------- Process Command Line ------------------------- */

/* SetConfParms: set conf parms relevant to this tool */
void SetConfParms(void)
{
   int i;
   double d;

   sampPeriod = 0.0; audSignal = NULLSIG;
   nParm = GetConfig("HLISTEN", TRUE, cParm, MAXGLOBS);
   if (nParm>0){
      if (GetConfInt(cParm,nParm,"AUDIOSIG",&i)) audSignal = i;
      if (GetConfInt(cParm,nParm,"TRACE",&i)) trace = i;
      if (GetConfFlt(cParm,nParm,"SOURCERATE",&d)) sampPeriod = d;
   }
}

void ReportUsage(void)
{
   printf("\nUSAGE: Hlisten [options] file ...\n\n");
   printf(" Option                                   Default\n\n");
   printf(" -p      Playback audio                      Off\n");
   PrintStdOpts("F");
   printf("\n\n");
}
   
int main(int argc, char *argv[])
{
   char *s,buf[MAXSTRLEN];
   void Listen(void);
   
   if(InitShell(argc,argv,hlisten_version)<SUCCESS)
      HError(1100,"Hlisten: InitShell failed");
   InitMem();
   InitMath();  InitSigP();
   InitWave();  InitAudio();
   SetConfParms();
   if (GetConfStr(cParm,nParm,"SOURCEFORMAT",buf))
      ff = Str2Format(buf);

   while (NextArg() == SWITCHARG) {
      s = GetSwtArg();
      if (strlen(s) !=1 )
         HError(1119,"Hlisten: Bad switch %s; must be single letter",s);
      switch(s[0]){
      case 'p':
         replay = TRUE; break;
      case 'F':
         if (NextArg() != STRINGARG)
            HError(1119,"Hlisten: File format expected");
         if((ff = Str2Format(GetStrArg())) == ALIEN)
            HError(-1189,"Hlisten: Warning ALIEN src file format set");
         break;
      case 'T':
         trace = GetChkedInt(0,077,s); break;
      default:
         HError(1119,"Hlisten: Unknown switch %s",s);
      }
   }

   Listen();
   return (0);          /* never reached -- make compiler happy */
}

/* -------------------- Display Routines  ------------------- */

#define AUDIO_BSIZE 1000      /* Audio Buffer Size */

/* Listen: list wave from audio device */
void Listen(void)
{
   AudioIn a;
   AudioOut b;

   int i,fsize,amp;
   float sum;
   float buf[1000];
   MemHeap x,y;

   printf(" Displaying Waveform from Audio Source\n");
   CreateHeap(&x,"AudioIn",  MSTAK, 1, 0.5, 100000, 5000000);
   CreateHeap(&y,"AudioOut", MSTAK, 1, 0.0, 100000, 500000);

   a = OpenAudioInput(&x,&sampPeriod, 100000.0, 100000.0);
   if (a==NULL)
      HError(1106,"Listen: No audio support");
   printf(" Sample Period = %f\n", sampPeriod);
   printf(" Samples per frame = %d\n",fsize=SampsInAudioFrame(a));
   printf(" AudSig = %d\n",audSignal);
   if (replay)
      AttachReplayBuf(a,100000);

   StartAudioInput(a,audSignal);
   while (GetAIStatus(a) != AI_CLEARED  || FramesInAudio(a)>0) {
     sum = 0.0;
     GetAudio(a, 1, buf);
     for (i=0; i<fsize; i++) sum += fabs(buf[i]);
     amp = 3*log(sum/fsize);
     for (i=0; i<amp; i++) putchar(' ');
     printf("*\n");
   }

   if (replay){
     b = OpenAudioOutput(&y,&sampPeriod);
     PlayReplayBuffer(b,a);
     while (SamplesToPlay(b) > 0 );
     CloseAudioOutput(b);
   }

   CloseAudioInput(a);
}



/* ----------------------------------------------------------- */
/*                      END:  Hlisten.c                          */
/* ----------------------------------------------------------- */
