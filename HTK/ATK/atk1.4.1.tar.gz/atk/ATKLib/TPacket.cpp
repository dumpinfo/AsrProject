/* ----------------------------------------------------------- */
/*                                                             */
/*                          ___                                */
/*                       /_\ | |_/                             */
/*                       | | | | \                             */
/*                       =========                             */
/*                                                             */
/*                                                             */
/*           Copyright Steve Young 2000-2002                   */
/*                                                             */
/* ----------------------------------------------------------- */
/*        File: TPacket.cpp    Test the Packet Classes         */
/* ----------------------------------------------------------- */

#include "APacket.h"

void ReportUsage(void)
{
   printf("\nUSAGE: TPacket n .... \n");
   printf("   1. Empty() \n");
   printf("   2. String() \n");
   printf("   3. Waveform() \n");
   printf("   4. Observation() \n");
   printf("   5. Command() \n");
   exit(1);
}

// -------------------- Test the Empty Packet --------------

void TestEmpty()
{
  printf("Testing the empty packet type\n");
  printf("Create empty packets e1 and e2 using APacket()\n");
  APacket e1,e2;
  e1.Show(); e2.Show();
  printf("Creating copy e3 of e1 using APacket(e1)\n");
  APacket e3(e1);
  e1.Show(); e2.Show(); e3.Show();
  printf("Assigning e1 to e2\n");
  e2 = e1;
  e1.Show(); e2.Show(); e3.Show();
  printf("\n");
}

// -------------------- Test the String Packet --------------

void TestString()
{
  printf("Testing the String packet type\n");
  printf("Create String packets s1=\"\" and s2=\"s2\"\n");
  APacket s1(new AStringData),s2(new AStringData("s2"));
  s1.Show(); s2.Show();
  printf("Creating copy s3 of s1 using APacket(s1)\n");
  APacket s3(s1);
  s1.Show(); s2.Show(); s3.Show();
  printf("Assigning s1 to s2\n");
  s2 = s1;
  s1.Show(); s2.Show(); s3.Show();
  printf("\n");
}

// -------------------- Test the Wave Packet --------------

void TestWave()
{
  short wav[100];
  printf("Testing the Wave packet type\n");
  for (int i=0; i<100; i++)wav[i]=i;
  printf("Create Wave packets w1=[] and w2=[1 2 3 ..]\n");
  APacket w1(new AWaveData),w2(new AWaveData(99,wav));
  w1.Show(); w2.Show();
  printf("Creating copy w3 of w1 using APacket(w1)\n");
  APacket w3(w1);
  w1.Show(); w2.Show(); w3.Show();
  printf("Assigning w1 to w2\n");
  w2 = w1;
  w1.Show(); w2.Show(); w3.Show();
  printf("Create Wave packet w4=[77 88] by explicitly accessing data\n");
  AWaveData *wd = new AWaveData;
  wd->wused = 2; wd->data[0] = 77; wd->data[1] = 88;
  APacket w4(wd);
  w4.Show();
  printf("\n");
}

// ------------------ Test the Observation Packet --------------

void TestObs()
{
  printf("Testing the Observation packet type\n");
  printf("  (fake BufferInfo tgtPK=FBANK and tgtVecSize=8)\n");
  BufferInfo info;

  info.tgtPK = FBANK; info.tgtVecSize = 8;
  APacket o(new AObsData(&info,1));
  o.Show();
  printf("\n");

}

// ------------------ Test the Command Packet ---------------

void TestCommand()
{
  ACommandData *ac = (ACommandData *)new ACommandData(GetStrArg());
  while (NumArgs()>0){
    switch(NextArg()){
    case INTARG:
      if (!ac->AddArg(GetIntArg())) HError(9999,"Cannot add integer arg"); 
      break;
    case STRINGARG:
      if (!ac->AddArg(GetStrArg())) HError(9999,"Cannot add string arg");
      break;
    case FLOATARG:
      if (!ac->AddArg(GetFltArg())) HError(9999,"Cannot add float arg");
      break;
    }
  }
  APacket cmd(ac);
  cmd.Show();
}

// -------------------- TPacket Main Program ---------------

int main(int argc, char *argv[])
{
  int n;
  printf("Packet test V2\n");
  if (InitHTK(argc,argv, "1.4.0")<SUCCESS){
    printf("Error: cannot initialise HTK\n"); exit(-1);
  }

  if (NextArg() == INTARG){
    n = GetIntArg();
    switch(n){
    case 1:
      TestEmpty();
      break;
    case 2:
      TestString();
      break;
    case 3:
      TestWave();
      break;
    case 4:
      TestObs();
      break;
    case 5:
      TestCommand();
      break;
    default:
      printf("Bad test number %d\n",n); ReportUsage(); 
    }
  }
  printf("Exiting TPacket: global packet count = %d\n",GetTotalPackets());
  return 0;
}

// ------------------------ End of TPacket -----------------
