/* ----------------------------------------------------------- */
/*                                                             */
/*                          ___                                */
/*                       /_\ | |_/                             */
/*                       | | | | \                             */
/*                       =========                             */
/*                                                             */
/*                                                             */
/*           Copyright Steve Young 2000-2002                   */
/*                                                             */
/* ----------------------------------------------------------- */
/*        File: THmms.cpp    Test the Hmms Class               */
/* ----------------------------------------------------------- */

#include "AHTK.h"
#include "ACode.h"
#include "AHmms.h"

void ReportUsage(void)
{
   printf("\nUSAGE: THmms -C config n .... \n");
   printf("   1. BasicLoad() \n");
   printf("   2. Load&Check() \n");
   exit(1);
}

// -------------------- Test Basic Hmm Set Loading --------------

void DoLoad(int stage)
{
  printf("Loading a HMM set...\n");
  AHmms hset("hmmset");
  if (stage<2) return;

  // set up a coder 
  printf("Setting up a coder ...\n");
  ABuffer auChan("auChan");
  ABuffer feChan("feChan");
  ACode acode("ACode",&auChan,&feChan);

  // check compatibility
  AObsData *od = acode.GetSpecimen();
  if (hset.CheckCompatible(&(od->data))) 
    printf("HMM set is compatible\n");
  else
    printf("HMM set IS NOT compatible\n");
}

// -------------------- THmms Main Program ---------------

int main(int argc, char *argv[])
{
  int n;
  printf("AHmms test\n");
  if (InitHTK(argc,argv)<SUCCESS){
    printf("Error: cannot initialise HTK\n"); exit(-1);
  }

  if (NextArg() == INTARG){
    n = GetIntArg();
    switch(n){
    case 1:
      DoLoad(1);
      break;
    case 2:
      DoLoad(2);
      break;    
    default:
      printf("Bad test number %d\n",n); ReportUsage(); 
    }
  }
}

// ------------------------ End of THmms -----------------
