/* ----------------------------------------------------------- */
/*                                                             */
/*                        _ ___                                */
/*                       /_\ | |_/                             */
/*                       | | | | \                             */
/*                       =========                             */
/*                                                             */
/*        Real-time API for HTK-base Speech Recognition        */
/*                                                             */
/*       Machine Intelligence Laboratory (Speech Group)        */
/*        Cambridge University Engineering Department          */
/*                  http://mi.eng.cam.ac.uk/                   */
/*                                                             */
/*               Copyright CUED 2000-2004                      */
/*                                                             */
/*   Use of this software is governed by a License Agreement   */
/*    ** See the file License for the Conditions of Use  **    */
/*    **     This banner notice must not be removed      **    */
/*                                                             */
/* ----------------------------------------------------------- */
/*     File: TRec.cpp -     Test the Recogniser component      */
/* ----------------------------------------------------------- */


static const char * version="!HVER!TRec:   1.2.0 [SJY 26/08/03]";


#include "AMonitor.h"
#include "ASource.h"
#include "ACode.h"
#include "ARec.h"

void ShowTime(APacket p)
{
   printf("[%7.3f -> %7.3f]\n ",p.GetStartTime()/1e7,p.GetEndTime()/1e7);
}


int main(int argc, char *argv[])
{
   APacket p;
   
   try {
      
      //if (NCInitHTK("config",version)<SUCCESS){
      if (InitHTK(argc,argv,version)<SUCCESS){
         ReportErrors("Main",0); exit(-1);
      }
      printf("TRec: Basic Recogniser Test\n");
      printf("TRec: HTK initialised\n");
      // Create Buffers
      ABuffer auChan("auChan");
      ABuffer feChan("feChan");
      ABuffer ansChan("ansChan");
      printf("TRec: Buffers initialised\n");
      // create a resource manager
      ARMan rman;
      
      // Create Audio Source and Coder
      ASource ain("AIn",&auChan);
      ACode acode("ACode",&auChan,&feChan);
      ARec  arec("ARec",&feChan,&ansChan,&rman,0);
      printf("TRec: Components initialised\n");
      
      // create global resources
      AHmms hset("HmmSet"); // load info in config
      ADict dict("ADict"); 
      AGram gram("AGram");
      rman.StoreHMMs(&hset);
      rman.StoreDict(&dict);
      rman.StoreGram(&gram);
      
      ResourceGroup *main = rman.NewGroup("main");
      main->AddHMMs(&hset);
      main->AddDict(&dict);
      main->AddGram(&gram);
      
      // Create Monitor and Start it
      AMonitor amon;
      amon.AddComponent(&ain);
      amon.AddComponent(&acode);
      amon.AddComponent(&arec);
      amon.Start();
      
      // Start components executing
      ain.Start(); 
      acode.Start();
      arec.Start();
      arec.SendMessage("usegrp(main)");
      arec.SendMessage("start()");
      AStringData mkrstr("mark");
      APacket mkr(&mkrstr);
      
      while (1) {
         // mkr.SetStartTime(GetTimeNow());
         // feChan.PutPacket(mkr);
         APacket p = ansChan.GetPacket();
         p.Show();
      }
      
      // Shutdown
      printf("Waiting for sys components\n");fflush(stdout);
      ain.Join(); 
      acode.Join();
      
      printf("Waiting for monitor\n");fflush(stdout);
      HJoinMonitor();
      return 0;
   }
   catch (ATK_Error e){ ReportErrors("ATK",e.i); return 0;}
   catch (HTK_Error e){ ReportErrors("HTK",e.i); return 0;}
}
