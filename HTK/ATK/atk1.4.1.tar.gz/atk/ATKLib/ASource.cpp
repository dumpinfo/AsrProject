/* ----------------------------------------------------------- */
/*                                                             */
/*                        _ ___                                */
/*                       /_\ | |_/                             */
/*                       | | | | \                             */
/*                       =========                             */
/*                                                             */
/*        Real-time API for HTK-base Speech Recognition        */
/*                                                             */
/*       Machine Intelligence Laboratory (Speech Group)        */
/*        Cambridge University Engineering Department          */
/*                  http://mi.eng.cam.ac.uk/                   */
/*                                                             */
/*               Copyright CUED 2000-2004                      */
/*                                                             */
/*   Use of this software is governed by a License Agreement   */
/*    ** See the file License for the Conditions of Use  **    */
/*    **     This banner notice must not be removed      **    */
/*                                                             */
/* ----------------------------------------------------------- */
/*    File: ASource.cpp -    Implementation of Audio Source    */
/* ----------------------------------------------------------- */

char * asource_version="!HVER!ASource:   1.4.1 [SJY 11/08/04]";

// Modification history:
//   9/12/02 - added PRBUFSIZE for printf display monitor
//   5/08/03 - standardised display config var names 
//  28/07/04 - included dc mean removal
//  11/08/04 - static variables removed

#include "ASource.h"

#define T_OUT 0002    // trace output packets

#define ASOURCEPRBUFSIZE 4

// ASource constructor, if cntlWin is supplied, then the volume control
// is drawn in the supplied window, otherwise a dedicated window is
// generated with a start/stop button
ASource::ASource(const string & name, ABuffer *outb, HWin cntlWin,
                 int cx0, int cy0, int cx1, int cy1)
                 : AComponent(name,(HasRealConsole()?2:ASOURCEPRBUFSIZE))
{
   char buf[100];
   ConfParam *cParm[MAXGLOBS];       /* config parameters */
   int numParm;
   int i; double f;
   Boolean b;
   string wfname;
   
   strcpy(buf,name.c_str()); 
   for (i=0; i<int(strlen(buf)); i++) buf[i] = toupper(buf[i]);
   numParm = GetConfig(buf, TRUE, cParm, MAXGLOBS);
   stopped = TRUE; out = outb;
   width = 120; height=30; showVM = FALSE; sampSent = 0;
   vmx0 = 30;   vmy0 = 10;  win = cntlWin; dcMean = 0; zeroMean = TRUE;
   timeNow = 0.0; flushmargin = 0.0; oldLevel = -1;
   sampPeriod = 0.0;  // ie default is to use device setting
   fmt = HAUDIO;      // default is to use direct audio input
   if (numParm>0){
      if (GetConfBool(cParm,numParm,"DISPSHOW",&b)) showVM = b;
      if (GetConfInt(cParm,numParm,"DISPXORIGIN",&i)) vmx0 = i;
      if (GetConfInt(cParm,numParm,"DISPYORIGIN",&i)) vmy0 = i;
      if (GetConfInt(cParm,numParm,"DISPWIDTH",&i)) width = i;
      if (GetConfInt(cParm,numParm,"DISPHEIGHT",&i)) height = i;
      if (GetConfStr(cParm,numParm,"WAVEFILE",buf)) {
         wfname = buf; wfnList.push_back(wfname);
      }
      if (GetConfFlt(cParm,numParm,"FLUSHMARGIN",&f)) flushmargin = f;
      if (GetConfBool(cParm,numParm,"ZEROMEAN",&b)) zeroMean = b;
      if (GetConfStr(cParm,numParm,"WAVELIST",buf))ReadWaveList(buf);
      if (GetConfStr(cParm,numParm,"SOURCEFORMAT",buf))
         fmt = Str2Format(buf);
      if (GetConfInt(cParm,numParm,"TRACE",&i)) trace = i;
   }
   x1 = cx0; x2 = cx1; y1 = cy0; y2 = cy1;    // used when drawing VM in ext win
}
// ASource constructor for specific file list
ASource::ASource(const string & name, ABuffer *outb, const string &filelist)
: AComponent(name,ASOURCEPRBUFSIZE)
{
   char buf[100];
   ConfParam *cParm[MAXGLOBS];       /* config parameters */
   int numParm;
   int i; double f;
   string wfname;
   Boolean b;
   
   strcpy(buf,name.c_str()); 
   for (i=0; i<int(strlen(buf)); i++) buf[i] = toupper(buf[i]);
   numParm = GetConfig(buf, TRUE, cParm, MAXGLOBS);
   stopped = TRUE; out = outb; dcMean = 0; zeroMean = TRUE;
   width = 120; height=30; showVM = FALSE; sampSent = 0;
   vmx0 = vmy0 = 0;  win = NULL; oldLevel = -1;
   timeNow = 0.0; flushmargin = 0.0;
   sampPeriod = 0.0;  // ie default is to use device setting
   fmt = HTK;      // default is HTK file format
   if (numParm>0){
      if (GetConfBool(cParm,numParm,"DISPSHOW",&b)) showVM = b;
      if (GetConfInt(cParm,numParm,"DISPXORIGIN",&i)) vmx0 = i;
      if (GetConfInt(cParm,numParm,"DISPYORIGIN",&i)) vmy0 = i;
      if (GetConfInt(cParm,numParm,"DISPWIDTH",&i)) width = i;
      if (GetConfInt(cParm,numParm,"DISPHEIGHT",&i)) height = i;
      if (GetConfFlt(cParm,numParm,"FLUSHMARGIN",&f)) flushmargin = f;
      if (GetConfBool(cParm,numParm,"ZEROMEAN",&b)) zeroMean = b;
      if (GetConfStr(cParm,numParm,"SOURCEFORMAT",buf))
         fmt = Str2Format(buf);
      if (GetConfInt(cParm,numParm,"TRACE",&i)) trace = i;
   }
   strcpy(buf,filelist.c_str());
   ReadWaveList(buf);
   x1 = x2 = y1 = y2 = 0;
}

// Read a list of file names from given file and store in wfnList
void ASource::ReadWaveList(char *fn)
{
   char listfn[512],buf[512],*s;
   int len;
   Boolean ok;
   FILE *f;
   
   strcpy(listfn,fn);
   ok = ((f = fopen(listfn,"r")) != NULL)?TRUE:FALSE;
   if (!ok){
      if (listfn[0]=='/') {
         listfn[0] = listfn[1]; listfn[1]=':';
         ok = ((f = fopen(listfn,"r")) != NULL)?TRUE:FALSE;
      }
   }
   if (! ok){
      HRError(10110,"Cannot open wavelist %s",fn);
      throw ATK_Error(10110);
   }
   while (fgets(buf,511,f) != NULL){
      for (s=buf; *s==' '; s++);
      if (*s != '\n'){
         len = strlen(s);
         if (s[len-1]=='\n') s[len-1] = '\0';
         wfnList.push_back(string(s));
      }
   }
}

// Start the task
void ASource::Start(HPriority priority)
{
   AComponent::Start(priority,ASource_Task);
}

// Return SampPeriod
HTime ASource::GetSampPeriod()
{
   return sampPeriod;
}

// Draw Button
void ASource::DrawButton()
{
   if (stopping)
      strcpy(ssbname,"Start");
   else
      strcpy(ssbname,"Stop");
   RedrawHButton(&ssb);
}

// Button Press
void ASource::ButtonPressed()
{
   if (stopped)
      StartCmd();
   else
      StopCmd();
}

// Draw VolMeter - level = 0 to 100, note that volMeter is normally
// drawn inside ASource's own windown.  But if DISPSHOW is false but
// win is not NULL, then win belongs to some other thread which has
// requested a volume meter.   In this latter case, x0 and y0 
// are set by DISPXORIGIN and DISPYORIGIN ie relative to supplied window
//
void ASource::DrawVM(int level)
{
   const int margin = 4;
   int but_w = 20;
   
   if (oldLevel < 0){
      // set up position info
      but_w = HTextWidth(win,"Start")+margin;
      if (showVM) {
         x0 = margin; y0 = margin;
         x1 = x0 + but_w + margin;     
         y1 = y0 + margin;
         x2 = width-margin;   y2 = height-margin;
         // paint background
         HSetGrey(win,40);
         HFillRectangle(win,0,0,width,height);
         // create button
         ssb.x = x0; ssb.y = y0; ssb.w = but_w; ssb.h = height-2*margin;
         ssb.fg = DARK_GREY; ssb.bg = LIGHT_GREY; ssb.lit = FALSE;
         ssb.active = TRUE; ssb.toggle = TRUE;  ssb.fontSize = 0;
         strcpy(ssbname,"Start"); ssb.str = ssbname;
         ssb.id = 1; ssb.win = win;
         ssb.next = 0; ssb.action = 0;
         RedrawHButton(&ssb);
         // draw outline for volume control
         HSetGrey(win,20);
         HDrawRectangle(win,x1-1,y1-1,x2+1,y2+1);
      }
   }
   if (level != oldLevel){
      float fx = float(level/100.0);
      int x = x1 + int((x2-x1)*fx);
      int xmax = x1 + int(0.7*(x2-x1));
      
      HSetColour(win,YELLOW);
      HFillRectangle(win,x1,y1,x2,y2);
      HSetColour(win,DARK_GREEN);
      HFillRectangle(win,x1,y1,x<xmax?x:xmax,y2);
      if (x>xmax){
         HSetColour(win,RED);
         HFillRectangle(win,xmax,y1,x<x2?x:x2,y2);
      }
   }
   oldLevel = level;
}

// Start the audio sampling
void ASource::StartCmd()
{
   string wfn;
   char buf[512];
   
   if (fmt == HAUDIO){
      timeNow = GetTimeNow();
      SendMarkerPkt("START");
      a = OpenAudioInput(&mem,&sampPeriod);
      if (a == NULL){
         HRError(10106,"ASource::StartCmd: Cannot open audio device");
         throw HTK_Error(10106);
      }
      StartAudioInput(a);
   }else {
      timeNow = 0.0;
      if (wfnList.size()==0){
         SendMarkerPkt("ENDOFLIST");
         return;
      }
      wfn = wfnList.front(); wfnList.pop_front();
      SendMarkerPkt("START ("+wfn+")");
      strcpy(buf,wfn.c_str());
      w = OpenWaveInput(&mem, buf, fmt, 0.0, 0.0, &sampPeriod);
      if (w==NULL){
         HRError(10110,"ASource::StartCmd: Cannot open wave %s",wfn.c_str());
         throw HTK_Error(10100);
      }
      wbuf = GetWaveDirect(w,&wSamps);
      widx = 0;
   }
   stopped = FALSE; stopping = FALSE;
   flushsamps = (long int) (flushmargin/sampPeriod);
   if (showVM) DrawButton();
}

// Stop the audio sampling
void ASource::StopCmd()
{
   if (fmt == HAUDIO) StopAudioInput(a);
   stopping = TRUE;
   if (showVM) DrawButton();
}

// Create and fill a wave data packet
APacket ASource::MakePacket(Boolean &isEmpty)
{
   int sampsAvail,sampsInAudio;
   
   // create a wavedata container and fill it
   AWaveData *wd = new AWaveData();
   if (fmt == HAUDIO){
      //  The normal source for ATK ie raw audio input
      if (stopping) {
         sampsInAudio = SamplesInAudio(a);
         if (sampsInAudio>WAVEPACKETSIZE) sampsInAudio=WAVEPACKETSIZE;
         sampsAvail = sampsInAudio + flushsamps;
         if (sampsAvail>WAVEPACKETSIZE) sampsAvail=WAVEPACKETSIZE;
         if (sampsInAudio>0) GetRawAudio(a,sampsInAudio,wd->data);
         for (int i=sampsInAudio; i<sampsAvail; i++){
            wd->data[i] = 0;  --flushsamps;
         }
         if (stopping && (SamplesInAudio(a)==0) && (flushsamps==0)){
            stopped = TRUE;
            CloseAudioInput(a);
         }
      } else {
         sampsAvail = WAVEPACKETSIZE;
         GetRawAudio(a,sampsAvail,wd->data);
      }
   } else {
      // The alternate source for testing - a file
      sampsAvail = wSamps-widx + flushsamps;
      if (sampsAvail>WAVEPACKETSIZE) sampsAvail=WAVEPACKETSIZE;
      if (sampsAvail < WAVEPACKETSIZE) {
         stopping = TRUE; stopped = TRUE; 
         if (showVM) DrawButton();
      }
      for (int i=0; i<sampsAvail; i++,widx++)
         wd->data[i] = (widx<wSamps)?wbuf[widx]:0;
      if (stopped) CloseWaveInput(w);
   }
   isEmpty = TRUE; wd->wused = 0;
   if (sampsAvail > 0){
      isEmpty = FALSE;
      if (sampsAvail<WAVEPACKETSIZE)  // pad with zeros
         for (int i=sampsAvail; i<WAVEPACKETSIZE; i++)
            wd->data[i] = (short int) FakeSilenceSample();
         wd->wused = WAVEPACKETSIZE;
   }
   // wrap it with a packet and return it.
   APacket newpkt(wd);
   newpkt.SetStartTime(timeNow);
   timeNow +=sampPeriod*WAVEPACKETSIZE;
   newpkt.SetEndTime(timeNow);
   return newpkt;
}

// Send a marker packet to output
void ASource::SendMarkerPkt(string marker)
{
   AStringData *sd = new AStringData(cname+"::"+marker);
   APacket mkrpkt(sd);
   mkrpkt.SetStartTime(timeNow);
   mkrpkt.SetEndTime(timeNow);
   out->PutPacket(mkrpkt);
   if (trace&T_OUT)mkrpkt.Show();
}

// Implement the command interface
void ASource::ExecCommand(const string & cmdname)
{  
   char buf[100];
   
   if (cmdname == "start") 
      StartCmd();
   else if (cmdname == "stop") 
      StopCmd(); 
   else {
      sprintf(buf,"Unknown command %s\n",cmdname.c_str());
      HPostMessage(HThreadSelf(),buf);
   }
}

// ASource task
TASKTYPE TASKMOD ASource_Task(void * p)
{
   ASource *asp = (ASource *)p;
   APacket pkt;
   int i;
   float sum,logvolume;
   char buf[100],cname[100];
   HEventRec e;
   AWaveData *wd;
   Boolean isEmpty;
   
   try{
      CreateHeap(&(asp->mem), "ASourceStack", MSTAK, 1, 1.0, 10000, 50000);
      strcpy(cname,asp->cname.c_str());
      if (asp->showVM && asp->win == NULL)
         asp->win = MakeHWin(cname,asp->vmx0,asp->vmy0,asp->width,asp->height,1);
      if (asp->win != NULL) asp->DrawVM(0);
      asp->RequestMessageEvents();
      while (!asp->IsTerminated()){
         if (!asp->stopped){
            pkt = asp->MakePacket(isEmpty);
            if (!isEmpty){
               wd = (AWaveData *)pkt.GetData(); 
               if (asp->zeroMean){
                  for (i=0,sum=0.0; i<wd->wused; i++) sum += wd->data[i];
                  sum /= wd->wused;
                  asp->dcMean =int(0.7*float(asp->dcMean) + 0.3*sum);
                  for (i=0; i<wd->wused; i++) wd->data[i] -= asp->dcMean;
               }
               if (asp->win != NULL){
                  for (i=0,sum=0.0; i<wd->wused; i++) sum += wd->data[i]*wd->data[i];
                  if (sum<1) logvolume=0.0; else{
                     logvolume = float(log(sum/wd->wused)-9)*8;  // do this properly 1 day
                  }
                  if (logvolume>100) logvolume=100;
                  if (logvolume<0) logvolume = 0;
                  asp->DrawVM((int)logvolume);
               }
               asp->out->PutPacket(pkt);
	       if (asp->trace&T_OUT)pkt.Show();
            }
            if (asp->stopped)asp->SendMarkerPkt("STOP");
         }
         if (asp->stopped || HEventsPending(0)){
            e = HGetEvent(0,0);
            switch(e.event){
            case HTBUFFER:
               if (e.c == MSGEVENTID) {
                  asp->ChkMessage();
                  while (asp->IsSuspended()) asp->ChkMessage(TRUE);
               }
               break;
            case HWINCLOSE:
               sprintf(buf, "terminating");
               HPostMessage(HThreadSelf(),buf);  
               asp->terminated = TRUE;
               break;
            case HMOUSEDOWN:
               if (TrackButtons(&(asp->ssb),e)>0)
                  asp->ButtonPressed();
            }
         }
      }
      HExitThread(0);
      return 0;
   }
   catch (ATK_Error e){ ReportErrors("ATK",e.i); return 0;}
   catch (HTK_Error e){ ReportErrors("HTK",e.i); return 0;}
}

// ----------------------End of ASource.cpp ---------------------
