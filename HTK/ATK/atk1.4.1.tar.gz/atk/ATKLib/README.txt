ATK Library

This directory contains the ATK library plus a number of simple test
programs.   The Test directory holds support files needed
to run the test programs.

Class Test Progams
------------------

TPacket			- test basic packet types and methods
TBuffer			- test basic buffer operation
TADict			- test dictionary loading
TAGram			- test grammar loading and editing
TAHmms			- test HMM loading
TARMan			- test basic resource management

Functional Test Progams
-----------------------

Each of these should be executed from the test directory where 
it has a specific config file, eg TBase.cfg

TBase			- displays 3 boxes holding red balls, click
			  on a box to move ball from one to another.
			  Tests functionality of core ATK object types
TSource			- test source, recording and playback
TCode			- test coder fed from audio source
TRec			- test recogniser




