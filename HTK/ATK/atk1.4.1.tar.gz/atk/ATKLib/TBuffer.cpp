/* ----------------------------------------------------------- */
/*                                                             */
/*                          ___                                */
/*                       /_\ | |_/                             */
/*                       | | | | \                             */
/*                       =========                             */
/*                                                             */
/*                                                             */
/*           Copyright Steve Young 2000-2002                   */
/*                                                             */
/* ----------------------------------------------------------- */
/*   File: TBuffer.cpp  Test the Buffer Class (single thread)  */
/* ----------------------------------------------------------- */

#include "APacket.h"
#include "ABuffer.h"

void ReportUsage(void)
{
   printf("\nUSAGE: TBuffer n .... \n");
   printf("   1. Basictest(size,ncycles,nput) \n");
   exit(1);
}

// -------------------- Basic Test --------------------------

void Basictest(int size,int ncycles,int nput)
{
  char cbuf[100];

  printf("Testing a buffer in single thread mode\n");
  printf("Create buffer size %d\n",size);
  ABuffer buf("testbuffer",size);
  printf("Send %d strings to buffer in %d cycles\n",nput,ncycles);
  for (int cycle=1; cycle<=ncycles; cycle++){
    printf("Cycle %d:\n",cycle);
    for (int i=1; i<=nput; i++){
      sprintf(cbuf,"Cycle %d item %d",cycle,i);
      APacket pkt(new AStringData(cbuf));
      buf.PutPacket(pkt);
    }
    printf(" put cycle %d finished:  %d pkts in buffer, globPkts=%d\n",
	   cycle,buf.NumPackets(),GetTotalPackets());
    for (i=1; i<=nput; i++){
      APacket pkt = buf.GetPacket();
      pkt.Show();
    }
    printf("\n end of cycle %d:  %d pkts in buffer, globPkts=%d\n",
	   cycle,buf.NumPackets(),GetTotalPackets());
  }
}


// -------------------- TBuffer Main Program ---------------

int main(int argc, char *argv[])
{
  int n,a,b,c;
  printf("Buffer test\n");
  if (InitHTK(argc,argv)<SUCCESS){
    printf("Error: cannot initialise HTK\n"); exit(-1);
  }

  if (NextArg() == INTARG){
    n = GetIntArg();
    switch(n){
    case 1:
      a = GetIntArg(); b = GetIntArg(); c = GetIntArg();
      Basictest(a,b,c);
      break;
    default:
      printf("Bad test number %d\n",n); ReportUsage(); 
    }
    printf("\nExiting TBuffer: global packet count = %d\n",GetTotalPackets());
  } else
    ReportUsage();
}

// ------------------------ End of TBuffer -----------------
