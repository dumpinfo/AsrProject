/* ----------------------------------------------------------- */
/*                                                             */
/*                        _ ___                                */
/*                       /_\ | |_/                             */
/*                       | | | | \                             */
/*                       =========                             */
/*                                                             */
/*        Real-time API for HTK-base Speech Recognition        */
/*                                                             */
/*       Machine Intelligence Laboratory (Speech Group)        */
/*        Cambridge University Engineering Department          */
/*                  http://mi.eng.cam.ac.uk/                   */
/*                                                             */
/*               Copyright CUED 2000-2004                      */
/*                                                             */
/*   Use of this software is governed by a License Agreement   */
/*    ** See the file License for the Conditions of Use  **    */
/*    **     This banner notice must not be removed      **    */
/*                                                             */
/* ----------------------------------------------------------- */
/*   File: TASource.cpp -     Test the Audio Input component   */
/* ----------------------------------------------------------- */

static const char * version="!HVER!TASource:   1.4.1 [SJY 04/08/04]";

#include "AMonitor.h"
#include "ASource.h"
#include "ACode.h"
#include "ARec.h"

#define OUTBUFSIZE 1000000

void ShowTime(APacket p)
{
   printf("[%7.3f -> %7.3f] ",p.GetStartTime()/1e7,p.GetEndTime()/1e7);
}

int main(int argc, char *argv[])
{
   APacket p;
   AWaveData *w;
   AStringData *sd;
   short *buf;
   MemHeap mem;
   HTime srate;
   
   try {
      if (InitHTK(argc,argv,version)<SUCCESS){
         // if (NCInitHTK("TSource.cfg",version)<SUCCESS){
         ReportErrors("Main",0); exit(-1);
      }
      printf("TASource: Audio Source Test\n");
      
      // Setup audio output
      CreateHeap(&mem, "ASinkStack", MSTAK, 1, 1.0, 10000, 50000);
      srate = 0.0;
      AudioOut a = OpenAudioOutput(&mem,&srate);
      if (a==0)
         HError(9999,"Cannot open audio output");
      printf("Audio output ready - srate = %.1f\n",srate);
      
      buf = (short *)malloc(OUTBUFSIZE*2);
      if (buf==0)
         HError(9999,"Cannot malloc output buffer");
      
      // Create Buffers
      ABuffer auChan("auChan");
      
      // Create Source
      ASource ain("AIn",&auChan);
      
      // Create Monitor and Start it
      AMonitor amon;
      amon.AddComponent(&ain);
      amon.Start();
      
      // Collect data from the audio source
      // display and replay it
      Boolean rxing;
      
      printf("Starting Audio Source Test\n");
      ain.Start();
      while (!ain.IsTerminated()){
         int j,i=0;    
         p = auChan.GetPacket();
         ShowTime(p);
         if (p.GetKind() != StringPacket)
            HError(0,"String packet expected\n");
         sd = (AStringData *) p.GetData();
         printf("MARKER: %s\n",sd->data.c_str());
         rxing = TRUE;
         while (!ain.IsTerminated() && (i<(OUTBUFSIZE-WAVEPACKETSIZE)) && rxing){
            p = auChan.GetPacket();
            ShowTime(p);
            switch (p.GetKind()){
            case  StringPacket:
               sd = (AStringData *) p.GetData();
               printf("MARKER: %s\n",sd->data.c_str());
               rxing = FALSE;
               break;
            case WavePacket:
               w = (AWaveData *)p.GetData();
               printf("WAVE: ");
               for (j=0; j<WAVEPACKETSIZE; j++){
                  buf[i++] = w->data[j];
                  if (j<6 || j>(WAVEPACKETSIZE-5)) printf("%6d",w->data[j]);
                  if (j==6) printf("  ...  ");
               }
               printf("\n");
               break;
            default:
               printf("*** Unexpected packet\n");
            }
         }
         printf("Source stopped - listen to output\n");  fflush(stdout);
         StartAudioOutput(a,i,buf);
         while (SamplesToPlay(a) > 0);
         printf("Continuing...\n");
      }
      ain.Join();
      // Shutdown
      printf("Waiting for monitor\n");fflush(stdout);
      HJoinMonitor();
      return 0;
   }
   catch (ATK_Error e){ ReportErrors("ATK",e.i); }
   catch (HTK_Error e){ ReportErrors("HTK",e.i); }
   return 0;
}
