/* ----------------------------------------------------------- */
/*                                                             */
/*                          ___                                */
/*                       /_\ | |_/                             */
/*                       | | | | \                             */
/*                       =========                             */
/*                                                             */
/*                                                             */
/*           Copyright Steve Young 2000-2002                   */
/*                                                             */
/* ----------------------------------------------------------- */
/*        File: TARMan.cpp    Test the ARMan Class             */
/* ----------------------------------------------------------- */

#include "AHTK.h"
#include "ARMan.h"

void ReportUsage(void)
{
   printf("\nUSAGE: TARMan -C config n .... \n");
   printf("   1. BasicLoad() \n");
   exit(1);
}

// -------------------- Test Basic Resource Loading --------------

void BasicLoad()
{  
  try{
    printf("Loading a HMM set...\n");
    AHmms *h1 = new AHmms("hmmset");

    printf("Loading dictionary ...\n");
    ADict *d1 = new ADict("ADict");

    printf("Loading a grammar ...\n");
    AGram *g1 = new AGram("AGram1","ATKLib/grams/eg1.net");
    AGram *g3 = new AGram("AGram3","ATKLib/grams/eg3.net");

    printf("Create a Resource Manager ... \n");
    ARMan rman;
    
    printf("Store resources in rman ... \n");
    rman.StoreHMMs(h1);
    rman.StoreDict(d1);
    rman.StoreGram(g1);
    rman.StoreGram(g3);
    
    printf("Check they can be found again ... \n");
    if (rman.FindHMMs("hmmset") != h1) printf("  cannot find hmmset\n"); else
      if (rman.FindDict("ADict") != d1) printf("  cannot find ADict\n"); else
	if (rman.FindGram("AGram1") != g1) printf("  cannot find AGram1\n"); else
	  if (rman.FindGram("AGram3") != g3) printf("  cannot find AGram3\n"); else
	    printf("  all ok\n");

    printf("Create a group .... \n");
    ResourceGroup *testgroup = rman.NewGroup("TestGroup");

    printf("Add resources to Group .... \n");
    testgroup->AddHMMs(h1);
    testgroup->AddDict(d1);
    testgroup->AddGram(g1);
    testgroup->AddGram(g3);

    printf("Make network from group ... \n");
    Network *net1 = testgroup->MakeNetwork();

    printf("Make a small edit - delete ONE from digits subnet\n");
    g1->OpenEdit();
    GramSubN *digsub = g1->FindSubN("digits");
    if (digsub==NULL) HError(999,"Cannot find digits grammar");
    GramNode *one = digsub->FindbyWord("ONE");
    if (one==NULL) HError(999,"Cannot find ONE node");
    digsub->DeleteNode(one);
    digsub->Show();
    g1->CloseEdit();
    printf("Make network again from edited group ... \n");
    Network *net2 = testgroup->MakeNetwork();
    
    printf("End of basic test\n");
  }
  catch (ATK_Error e){
    int n = HRErrorCount();
    printf("ATK Error %d\n",e.i);
    for (int i=1; i<=n; i++)
      printf("  %d. %s\n",i,HRErrorGetMess(i));
  }
  catch (HTK_Error e){
    int n = HRErrorCount();
    printf("HTK Error %d\n",e.i);
    for (int i=1; i<=n; i++)
      printf("  %d. %s\n",i,HRErrorGetMess(i));
  }
}

// -------------------- TARMan Main Program ---------------

int main(int argc, char *argv[])
{
  int n;
  printf("ARMan test\n");
  if (InitHTK(argc,argv)<SUCCESS){
    printf("Error: cannot initialise HTK\n"); exit(-1);
  }

  if (NextArg() == INTARG){
    n = GetIntArg();
    switch(n){
    case 1:
      BasicLoad();
      break;
    default:
      printf("Bad test number %d\n",n); ReportUsage(); 
    }
  }
  return 0;
}

// ------------------------ End of TARMan.cpp -----------------
