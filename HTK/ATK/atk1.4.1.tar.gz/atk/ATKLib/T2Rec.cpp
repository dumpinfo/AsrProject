/* ----------------------------------------------------------- */
/*                                                             */
/*                        _ ___                                */
/*                       /_\ | |_/                             */
/*                       | | | | \                             */
/*                       =========                             */
/*                                                             */
/*        Real-time API for HTK-base Speech Recognition        */
/*                                                             */
/*       Machine Intelligence Laboratory (Speech Group)        */
/*        Cambridge University Engineering Department          */
/*                  http://mi.eng.cam.ac.uk/                   */
/*                                                             */
/*               Copyright CUED 2000-2004                      */
/*                                                             */
/*   Use of this software is governed by a License Agreement   */
/*    ** See the file License for the Conditions of Use  **    */
/*    **     This banner notice must not be removed      **    */
/*                                                             */
/* ----------------------------------------------------------- */
/*     File: T2Rec.cpp -     Test dual recognisers             */
/* ----------------------------------------------------------- */


static const char * version="!HVER!T2Rec:   0.0 [SJY 11/08/04]";


#include "AMonitor.h"
#include "ASource.h"
#include "ACode.h"
#include "ARec.h"

// ------------------- ABiFe Class --------------------------------

class ABiFe: public AComponent {
 public:
  ABiFe(const string &name, ABuffer *inb, ABuffer *outb1, ABuffer *outb2);
  void Start(HPriority priority=HPRIO_NORM);
 private:
  friend TASKTYPE TASKMOD CopyFe(void *p);
  void ExecCommand(const string &cmdname);
  ABuffer *in, *out1, *out2;
};

// ABiFe constructor
ABiFe::ABiFe(const string &name, ABuffer *inb, ABuffer *outb1, ABuffer *outb2)
: AComponent(name,2)
{
  in=inb;
  out1=outb1;
  out2=outb2;
}

TASKTYPE TASKMOD CopyFe(void *p)
{
  ABiFe *acp = (ABiFe *)p;
  APacket pkt;
  try{
    while(!acp->IsTerminated()){
      pkt=acp->in->GetPacket();
      acp->out1->PutPacket(pkt);
      acp->out2->PutPacket(pkt);
    }
  }
  catch (ATK_Error e){ReportErrors("ATK",e.i); return 0;}
  catch (HTK_Error e){ReportErrors("HTK",e.i); return 0;}
}

// Start the task
void ABiFe::Start(HPriority priority)
{
   AComponent::Start(priority,CopyFe);
}

// Implement the command interface
void ABiFe::ExecCommand(const string & cmdname)
{
  return;
}

void ShowTime(APacket p)
{
   printf("[%7.3f -> %7.3f]\n ",p.GetStartTime()/1e7,p.GetEndTime()/1e7);
}


int main(int argc, char *argv[])
{
   APacket p;
   
   try {
      
      //if (NCInitHTK("config",version)<SUCCESS){
      if (InitHTK(argc,argv,version)<SUCCESS){
         ReportErrors("Main",0); exit(-1);
      }
      printf("T2Rec: Two Recogniser Test\n");
      printf("T2Rec: HTK initialised\n");
      // Create Buffers
      ABuffer auChan("auChan");
      ABuffer feChan("feChan");
      ABuffer feChan1("feChan1");
      ABuffer feChan2("feChan2");
      ABuffer ansChan1("ansChan1");
      ABuffer ansChan2("ansChan2");
      printf("T2Rec: Buffers initialised\n");
      // create a resource manager
      ARMan rman1, rman2;
      
      // Create Audio Source and Coder
      ASource ain("AIn",&auChan);
      ACode acode("ACode",&auChan,&feChan);
      ABiFe abife("ABiFe",&feChan,&feChan1,&feChan2);
      ARec  arec1("ARec1",&feChan1,&ansChan1,&rman1,0);
      ARec  arec2("ARec2",&feChan2,&ansChan2,&rman2,0);
      printf("T2Rec: Components initialised\n");
      
      // create global resources
      AHmms hset1("HmmSet"); // load info in config
      ADict dict1("ADict"); 
      AGram gram1("AGram");
      rman1.StoreHMMs(&hset1);
      rman1.StoreDict(&dict1);
      rman1.StoreGram(&gram1);
      
      ResourceGroup *main1 = rman1.NewGroup("main1");
      main1->AddHMMs(&hset1);
      main1->AddDict(&dict1);
      main1->AddGram(&gram1);
      
      // create global resources
      AHmms hset2("HmmSet"); // load info in config
      ADict dict2("ADict"); 
      AGram gram2("AGram");
      rman2.StoreHMMs(&hset2);
      rman2.StoreDict(&dict2);
      rman2.StoreGram(&gram2);
      
      ResourceGroup *main2 = rman2.NewGroup("main2");
      main2->AddHMMs(&hset2);
      main2->AddDict(&dict2);
      main2->AddGram(&gram2);

      // Create Monitor and Start it
      AMonitor amon;
      amon.AddComponent(&ain);
      amon.AddComponent(&acode);
      amon.AddComponent(&arec1);
      amon.AddComponent(&arec2);
      amon.Start();
      
      // Start components executing
      ain.Start(); 
      acode.Start();
      abife.Start();
      arec1.Start();
      arec1.SendMessage("usegrp(main1)");
      arec1.SendMessage("start()");

      arec2.Start();
      arec2.SendMessage("usegrp(main2)");
      arec2.SendMessage("start()");
      
      AStringData mkrstr("mark");
      APacket mkr(&mkrstr);
      
      while (1) {
         // mkr.SetStartTime(GetTimeNow());
         // feChan.PutPacket(mkr);
         APacket p = ansChan1.GetPacket();
         p.Show();
         p = ansChan2.GetPacket();
         p.Show();
      }
      
      // Shutdown
      printf("Waiting for sys components\n");fflush(stdout);
      ain.Join(); 
      acode.Join();
      
      printf("Waiting for monitor\n");fflush(stdout);
      HJoinMonitor();
      return 0;
   }
   catch (ATK_Error e){ ReportErrors("ATK",e.i); return 0;}
   catch (HTK_Error e){ ReportErrors("HTK",e.i); return 0;}
}
