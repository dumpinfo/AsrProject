/* ----------------------------------------------------------- */
/*                                                             */
/*                          ___                                */
/*                       /_\ | |_/                             */
/*                       | | | | \                             */
/*                       =========                             */
/*                                                             */
/*                                                             */
/*                                                             */
/*           Copyright Steve Young 2000-2002                   */
/*                                                             */
/* ----------------------------------------------------------- */
/*        File: TGram.cpp    Test the Gram Class               */
/* ----------------------------------------------------------- */

#include "AHTK.h"
#include "AGram.h"

void ReportUsage(void)
{
   printf("\nUSAGE: TGram -C config n .... \n");
   printf("   1. BasicLoad() \n");
   printf("   2. BasicEdit() \n");
   printf("   3. BasicCopy() \n");
   printf("   4. SaveRestore() \n");
   exit(1);
}

// -------------------- Test Basic Grammar Loading --------------

void BasicLoad()
{
  printf("Loading a grammar ...\n");
  AGram gram("AGram");
  printf("Grammar loaded\n");
  gram.Show();
}
// -------------------- Test Basic Grammar Editing ----------

void BasicEdit()
{
  printf("Creating empty grammar ...\n");
  AGram gram("AGram","");
  printf("Editing grammar\n");
  gram.OpenEdit();
  GramSubN * s = gram.NewSubN("subnet1");
  GramNode * n1 = s->NewWordNode("hello","tag1");
  GramNode * n2 = s->NewWordNode("world","tag2");
  GramNode * n3 = s->NewWordNode("end");
  s->SetEnds(n1,n3);
  s->AddLink(n1,n2); s->AddLink(n2,n3);
  s->AddLink(n1,n3);
  printf("3 nodes added and linked hello->world->end\n");
  if (s->IsValid(TRUE))
    printf("Subnet is valid\n");
  else
    printf("Subnet is not valid\n");
  s->NormaliseProbs();
  gram.CloseEdit();
  gram.Show();
  printf("Grammar created\n");
}

void BasicCopy()
{
  printf("Loading a grammar ...\n");
  AGram gram("AGram");
  printf("Grammar loaded\n");
  gram.Show();
  printf("\n Copying this grammar\n");
  AGram copy1(gram);
  copy1.Show();
  printf("\n Assigning this grammar\n");
  AGram copy2 = gram;
  copy2.Show();
}

void SaveRestore()
{
  printf("Creating simple grammar ...\n");
  AGram gram("AGram","");
  gram.OpenEdit();
  GramSubN * s = gram.NewSubN("subnet1");
  GramNode * n1 = s->NewWordNode("hello","tag1");
  GramNode * n2 = s->NewWordNode("world","tag2");
  GramNode * n3 = s->NewWordNode("end");
  s->SetEnds(n1,n3);
  s->AddLink(n1,n2); s->AddLink(n2,n3);
  s->AddLink(n1,n3);
  gram.CloseEdit();
  printf("Here is version 1\n");
  gram.Show();
  printf("Now save it and modify v1\n");
  gram.Save();
  s->DeleteNode(n2);
  printf("Here is version 2\n");
  gram.Show();
  printf("Now restore from backup\n");
  gram.Restore();
  printf("Here is version 3\n");
  gram.Show();
  printf("End of test\n");
}

// -------------------- TGram Main Program ---------------

int main(int argc, char *argv[])
{

  int n;

  try{
    printf("AGram test\n");
    if (InitHTK(argc,argv)<SUCCESS){
      printf("Error: cannot initialise HTK\n"); exit(-1);
    }

    if (NextArg() == INTARG){
      n = GetIntArg();
      switch(n){
      case 1:
	BasicLoad();
	break;
      case 2:
	BasicEdit();
	break;
      case 3:
	BasicCopy();
	break;      
      case 4:
	SaveRestore();
	break;      
      default:
	printf("Bad test number %d\n",n); ReportUsage(); 
      }
    }
  }
  catch (ATK_Error e){
    int n = HRErrorCount();
    printf("ATK Error %d\n",e.i);
    for (int i=1; i<=n; i++)
      printf("  %d. %s\n",i,HRErrorGetMess(i));
  }
  catch (HTK_Error e){
    int n = HRErrorCount();
    printf("HTK Error %d\n",e.i);
    for (int i=1; i<=n; i++)
      printf("  %d. %s\n",i,HRErrorGetMess(i));
  }
}

// ------------------------ End of TGram -----------------
