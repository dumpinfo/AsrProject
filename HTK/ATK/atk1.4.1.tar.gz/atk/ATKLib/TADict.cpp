/* ----------------------------------------------------------- */
/*                                                             */
/*                          ___                                */
/*                       /_\ | |_/                             */
/*                       | | | | \                             */
/*                       =========                             */
/*                                                             */
/*                                                             */
/*           Copyright Steve Young 2000-2002                   */
/*                                                             */
/* ----------------------------------------------------------- */
/*        File: TDict.cpp    Test the Dict Class               */
/* ----------------------------------------------------------- */

#include "AHTK.h"
#include "ADict.h"

void ReportUsage(void)
{
   printf("\nUSAGE: TDict -C config n .... \n");
   printf("   1. BasicLoad() \n");
   printf("   2. CheckWord(word) \n");
   printf("   3. DeleteWord(word) \n");
   printf("   4. AddWord(word,'p1 p2 p3 ..') \n");
   exit(1);
}

// -------------------- Test Basic Dictionary Loading --------------

void BasicLoad()
{
  printf("Loading a Dictionary ...\n");
  ADict dict("ADict");
  printf("Dictionary loaded\n");
  dict.Show();
}

void CheckWord(char *w)
{
  printf("Loading a Dictionary ...\n");
  ADict dict("ADict");
  printf("Dictionary loaded\n");
  printf("Looking for %s: ",w);
  if (dict.HasWord(string(w)))
    printf("found\n");
  else
    printf("not found\n");
}

void DeleteWord(char *w)
{
  string word(w);

  printf("Loading a Dictionary ...\n");
  ADict dict("ADict");
  printf("Dictionary loaded\n");

  WordEntry we = dict.FindWord(word);
  if (we.w == NULL)
    printf("Cant find %s to delete\n",w);
  else {
    we.Show();
    dict.RemoveWord(we);
    dict.Show();
  }
}

void AddWord(char *w, char *pron)
{
  string sw(w);
  printf("Loading a Dictionary ...\n");
  ADict dict("ADict");
  printf("Adding word %s with pron %s\n",w,pron);
  Pronunciation p1(sw+"1",string(pron),0.6);
  Pronunciation p2(sw+"2",string(pron),0.4);
  WordEntry we(sw,p1,p2);
  dict.UpdateWord(we);
  we.Show();
  dict.Show();
}

// -------------------- TDict Main Program ---------------

int main(int argc, char *argv[])
{
  try{
    int n;
    char *w, *pr;

    printf("ADict test\n");
    if (InitHTK(argc,argv)<SUCCESS){
      printf("Error: cannot initialise HTK\n"); exit(-1);
    }
    if (NextArg() == INTARG){
      n = GetIntArg();
      switch(n){
      case 1:
	BasicLoad();
	break;
      case 2:
	CheckWord(GetStrArg());
	break;
      case 3:
	DeleteWord(GetStrArg());
	break;
      case 4:
	w = GetStrArg();
	pr = GetStrArg();
	AddWord(w,pr);
	break;
      default:
	printf("Bad test number %d\n",n); ReportUsage(); 
      }
    }
  }
  catch (ATK_Error e){
    int n = HRErrorCount();
    printf("ATK Error %d\n",e.i);
    for (int i=1; i<=n; i++)
      printf("  %d. %s\n",i,HRErrorGetMess(i));
  }
  catch (HTK_Error e){
    int n = HRErrorCount();
    printf("HTK Error %d\n",e.i);
    for (int i=1; i<=n; i++)
      printf("  %d. %s\n",i,HRErrorGetMess(i));
  }
}

// ------------------------ End of TDict -----------------
