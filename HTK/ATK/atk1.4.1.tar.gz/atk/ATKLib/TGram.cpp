/* ----------------------------------------------------------- */
/*                                                             */
/*                        _ ___                                */
/*                       /_\ | |_/                             */
/*                       | | | | \                             */
/*                       =========                             */
/*                                                             */
/*        Real-time API for HTK-base Speech Recognition        */
/*                                                             */
/*       Machine Intelligence Laboratory (Speech Group)        */
/*        Cambridge University Engineering Department          */
/*                  http://mi.eng.cam.ac.uk/                   */
/*                                                             */
/*               Copyright CUED 2000-2004                      */
/*                                                             */
/*   Use of this software is governed by a License Agreement   */
/*    ** See the file License for the Conditions of Use  **    */
/*    **     This banner notice must not be removed      **    */
/*                                                             */
/* ----------------------------------------------------------- */
/*          File: TGram.cpp -     Test Grammar Files           */
/* ----------------------------------------------------------- */

static const char * version="!HVER!TGram:   1.2.1 [SJY 16/10/03]";

#include "AHTK.h"
#include "ADict.h"
#include "AGram.h"

static int count = 10;				// number of random utterances to generate
static int limit = 100;          // max words per sentence
static Boolean annotate = FALSE; // enable annotate output

static char * dictfn = NULL;		// dictionary file to use/check, if any
static char * gramfn = NULL;		// grammar file to use

typedef AGram * AGramLink;
typedef list<AGramLink> AGramList;
typedef AGramList::iterator GramIterator;

static AGram *gram = NULL;
static ADict *dict = NULL;
static AGramList gramlist;      // list of loaded grammars

static int wcount;

void ReportUsage(void)
{
   printf("\nUSAGE: TGram [options] gramfile .... \n");
   printf("       -C cfg      set config file\n");
   printf("       -a          enable annotated output\n");
   printf("       -d dictfn   load dictionary and check coverage\n");
   printf("       -n count    set num sentences to generate [default 10]\n");
   printf("       -l limit    set max sentence length       [default 100]\n");
   exit(1);
}

// -------------------- Gram list handling -----------------

void FindMain(void)
{
   GramIterator gi;
   GramSubN *main;
   
   gram = NULL;
   for (gi=gramlist.begin(); gi != gramlist.end(); gi++){
      if ((*gi)->main !=NULL) {
         if (gram != NULL){
            HRError(999,"TGram: multiple main networks loaded");
            throw ATK_Error(999);
         }
         gram = (*gi);
      }
   }
   
}

GramSubN * FindSubnetwork(string name)
{
   GramIterator gi;
   GramSubN * sub;
   
   for (gi=gramlist.begin(); gi != gramlist.end(); gi++){
      sub = (*gi)->FindSubN(name);
      if (sub != NULL) return sub;
   }
   HRError(999,"TGram: cannot find nested subnetwork %s",name.c_str());
   throw ATK_Error(999);
   
}

// -------------------- Dictionary Check -----------------

void CheckDict()
{
   GramIterator gi;
   SubNIterator si;
   NodeIterator ni;
   Boolean isOk = TRUE;
   
   for (gi=gramlist.begin(); gi != gramlist.end(); gi++){
      for (si=(*gi)->subs.begin(); si != (*gi)->subs.end(); ++si) {
         for (ni=(*si)->nodes.begin(); ni != (*si)->nodes.end(); ++ni) {
            if ((*ni)->kind == WordNode){
               if (!dict->HasWord((*ni)->name)){
                  HRError(999,"Word %s not in %s\n",(*ni)->name.c_str(),dictfn);
                  isOk = FALSE;
               }
            }
         }
      }
   }
   if (!isOk) throw ATK_Error(999);
}

// -------------------- Sentence Generator ---------------

GramNode * SelectNext(GramNode *node)
{
   GramNode *next;
   LinkIterator li = node->succ.begin();
   int i = node->succ.size();
   float r = RandomValue()*i;
   
   if (i<1){
      HError(999,"Net final node is not exit in %s",node->name.c_str());
      throw ATK_Error(999);
   }
   
   while (r>1.0 && i > 1 ) { --i; ++li; r -= 1.0;}
   
   next = (*li).node;
   if (next==NULL) {
      HError(999,"Net final node is not exit in %s",node->name.c_str());
      throw ATK_Error(999);
   }
   return next;
}

void GenPhrase(GramSubN *subn)
{
   GramNode *n = subn->entry;
   GramSubN * nestedSub;
   
   while (n != subn->exit && wcount < limit) {
      switch(n->kind){
      case WordNode:
         printf("%s",n->name.c_str());
         if (n->stag != "" && annotate) printf("{%s}",n->stag.c_str());
         printf(" "); ++wcount;
         break;
      case NullNode:
         if (annotate){
            printf("<%s>",n->name.c_str());
            if (n->stag != "") printf("{%s}",n->stag.c_str());
            printf(" ");
         }
         break;
      case CallNode:
         nestedSub = FindSubnetwork(n->name); 
         if (annotate) printf("[");
         GenPhrase(nestedSub);
         if (annotate) {
            printf(" %s]",n->name.c_str());
            if (n->stag != "") printf("{%s}",n->stag.c_str());
         }
         break;
      default:
         printf("??? ");
         break;
      }
      n = SelectNext(n);
   }
}

void Generate()
{
   int n;
   
   printf("\n");
   for (n=1; n<=count; n++){
      wcount = 0;
      GenPhrase(gram->main);
      printf("\n");
   }
}

// -------------------- TGram Main Program ---------------

int main(int argc, char *argv[])
{
   
   char *s;
   
   try{
      if (InitHTK(argc,argv,version)<SUCCESS){
         ReportErrors("Main",0); exit(-1);
      }
      if (!InfoPrinted() && NumArgs() == 0)
         ReportUsage();
      if (NumArgs() == 0) exit(0);
      
      while (NextArg() == SWITCHARG) {
         s = GetSwtArg();
         if (strlen(s)!=1) {
            printf("Bad switch %s; must be single letter",s); ReportUsage(); 
         }
         switch(s[0]){
         case 'a':
            annotate = TRUE;
            break;
         case 'd':
            if (NextArg() != STRINGARG) {
               printf("Dictionary file name expected\n"); ReportUsage(); 
            }
            dictfn = GetStrArg();
            printf("Loading dict file %s\n",dictfn);
            dict = new ADict(dictfn,dictfn);
            if (dict==NULL){
               printf("Dictionary file %s failed to load\n",dictfn); ReportUsage();
            }
            break;
         case 'n': 
            if (NextArg() != INTARG) {
               printf("Integer count expected\n"); ReportUsage(); 
            }
            count = GetIntArg();
            break;
         case 'l': 
            if (NextArg() != INTARG) {
               printf("Max sentence length expected\n"); ReportUsage(); 
            }
            limit = GetIntArg();
            break;
         default:
            printf("Unknown switch %s\n",s); ReportUsage(); 
         }
      }
      if (NextArg() != STRINGARG) {
         printf("Name of gram file expected\n",s); ReportUsage(); 
      }
      while (NextArg() == STRINGARG) {
         gramfn = GetStrArg();
         printf("Loading gram file %s\n",gramfn);
         gram = new AGram("gram",gramfn);
         gramlist.push_front(gram);
      }
      FindMain();
      if (dict != NULL) CheckDict();
      Generate();
      return 0;
   }
   catch (ATK_Error e){ ReportErrors("ATK",e.i); return 0;}
   catch (HTK_Error e){ ReportErrors("HTK",e.i); return 0;}
}

// ------------------------ End of TGram -----------------
