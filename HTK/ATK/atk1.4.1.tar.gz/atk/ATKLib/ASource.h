/* ----------------------------------------------------------- */
/*                                                             */
/*                        _ ___                                */
/*                       /_\ | |_/                             */
/*                       | | | | \                             */
/*                       =========                             */
/*                                                             */
/*        Real-time API for HTK-base Speech Recognition        */
/*                                                             */
/*       Machine Intelligence Laboratory (Speech Group)        */
/*        Cambridge University Engineering Department          */
/*                  http://mi.eng.cam.ac.uk/                   */
/*                                                             */
/*               Copyright CUED 2000-2004                      */
/*                                                             */
/*   Use of this software is governed by a License Agreement   */
/*    ** See the file License for the Conditions of Use  **    */
/*    **     This banner notice must not be removed      **    */
/*                                                             */
/* ----------------------------------------------------------- */
/*     File: ASource.h -    Interface to the Audio Source      */
/* ----------------------------------------------------------- */



// Configuration variables (Defaults as shown)
//       SOURCEFORMAT = HAUDIO  -- source is direct audio
// ASOURCE: SHOWVM    = T       -- create a volume meter
// ASOURCE: VMXORIGIN = 30      -- top-left X coord of VM Window
// ASOURCE: VMYORIGIN = 10      -- top-left Y coord of VM Window
// ASOURCE: VMHEIGHT  = 30      -- height of volume meter
// ASOURCE: VMWIDTH   = 120     -- width of volume meter
// ASOURCE: WAVEFILE = ""       -- source an audio file
// ASOURCE: WAVELIST = ""       -- list of audio source files
// ASOURCE: ZEROMEAN = T        -- zero mean the source data

#include <stdio.h>
#ifndef _ATK_ASource
#define _ATK_ASource

#include "AComponent.h"

class ASource: public AComponent {
public:
  ASource(){}
  // general graphical interface version
  ASource(const string & name, ABuffer *outb, HWin cntlWin = NULL,
          int cx0 = 0, int cy0 = 0, int cx1 = 0, int cy1 = 0);
  // version for use by AVite to read only from filelist
  ASource::ASource(const string & name, ABuffer *outb, const string &filelist);
  void Start(HPriority priority=HPRIO_NORM);
  HTime GetSampPeriod();
private:
  friend TASKTYPE TASKMOD ASource_Task(void *p);
  void ReadWaveList(char *fn);
  void DrawVM(int level);
  void DrawButton();
  void ButtonPressed();
  void StartCmd();
  void StopCmd();
  void SendMarkerPkt(string marker);
  APacket MakePacket(Boolean &isEmpty);
  void ExecCommand(const string & cmdname);
  MemHeap mem;         // heap for HAudio 
  FileFormat fmt;      // source format (default HAUDIO)
  AudioIn a;           // HTK audio input object
  Wave w;              // alternative audio source file
  list<string> wfnList; // list of file names
  short *wbuf;         //  ... its data
  long wSamps;         //  ... num samps in wbuf
  long widx;           //  ... index into wbuf
  long sampSent;       // total samples sent
  HTime flushmargin;   // duration of zeros to send when STOP cmd rxed (default=0)
  long flushsamps;     // number of flush samples left
  int dcMean;          // dcMean removal
  Boolean zeroMean;    // enable dcMean removal
  HTime timeNow;       // used to track time
  HTime sampPeriod;    // Sample period
  Boolean stopping;    // TRUE when stopping sampling
  Boolean stopped;     // TRUE when sampling is temporarily stopped
  HWin win;            // display window
  Boolean showVM;      // show volmeter if TRUE
  int oldLevel;        // old display level
  int vmx0,vmy0;       // origin of VM window
  int width,height;    // width and height of VM window
  int x0,y0,x1,y1,x2,y2;  // VM fixed points
  ABuffer *out;        // output buffer
  HButton ssb;         // start/stop button
  char ssbname[12];    // button name
  int trace;           // tracing
};



#endif

/*  -------------------- End of ASource.h --------------------- */

